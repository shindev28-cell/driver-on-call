const admin = require("firebase-admin");

const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
if (!raw) throw new Error("Missing FIREBASE_SERVICE_ACCOUNT_JSON secret.");

admin.initializeApp({ credential: admin.credential.cert(JSON.parse(raw)) });
const db = admin.firestore();

async function sendDriverRequestNotifications() {
  const cutoff = Date.now() - 30 * 60 * 1000;
  const requests = await db.collection("driver_requests")
    .where("status", "==", "pending")
    .get();

  const drivers = await db.collection("drivers")
    .where("isOnline", "==", true)
    .get();

  let sent = 0;
  for (const request of requests.docs) {
    const data = request.data();
    const created = data.createdAt?.toDate?.();
    if (!created || created.getTime() < cutoff) continue;

    for (const driver of drivers.docs) {
      const driverData = driver.data();
      const approved = driverData.adminApproved === true || driverData.adminStatus === "approved";
      const verified = String(driverData.kycStatus || "pending").toLowerCase() === "verified";
      const blocked = driverData.adminBlocked === true || driverData.adminStatus === "blocked";
      if (!approved || !verified || blocked) continue;

      const tokenDoc = await db.collection("user_notification_tokens").doc(driver.id).get();
      const token = String(tokenDoc.data()?.token || "").trim();
      if (!token) continue;

      const deliveryRef = db.collection("driver_request_notifications")
        .doc(request.id).collection("deliveries").doc(driver.id);
      const delivery = await deliveryRef.get();
      if (delivery.exists) continue;

      try {
        await admin.messaging().send({
          token,
          notification: {
            title: "नवीन Driver Booking 🚗",
            body: `${data.vehicle || "Vehicle"} • ${data.duration || ""} • अंदाजे ₹${data.fare || ""}`,
          },
          data: {
            type: "driver_request",
            requestId: request.id,
            status: "pending",
          },
          android: { priority: "high" },
        });
        await deliveryRef.set({
          sentAt: admin.firestore.FieldValue.serverTimestamp(),
          token: token,
        });
        sent++;
      } catch (error) {
        console.error(`Driver notification failed for ${request.id}/${driver.id}:`, error.message);
      }
    }
  }
  return sent;
}

async function sendCustomerAcceptanceNotifications() {
  const cutoff = Date.now() - 30 * 60 * 1000;
  const snapshot = await db.collection("driver_requests")
    .where("status", "==", "accepted")
    .get();

  let sent = 0;
  for (const doc of snapshot.docs) {
    const data = doc.data();
    if (data.customerNotificationSentAt) continue;
    const updated = data.updatedAt?.toDate?.() || data.acceptedAt?.toDate?.();
    if (!updated || updated.getTime() < cutoff) continue;

    const customerId = String(data.customerId || "").trim();
    if (!customerId) continue;
    const tokenDoc = await db.collection("user_notification_tokens").doc(customerId).get();
    const token = String(tokenDoc.data()?.token || "").trim();
    if (!token) continue;

    try {
      await admin.messaging().send({
        token,
        notification: {
          title: "Driver मिळाला! ✅",
          body: `${data.driverName || "Driver"} तुमची booking स्वीकारली आहे.`,
        },
        data: {
          type: "driver_request_accepted",
          requestId: doc.id,
          status: "accepted",
        },
        android: { priority: "high" },
      });
      await doc.ref.update({
        customerNotificationSentAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      sent++;
    } catch (error) {
      console.error(`Customer notification failed for ${doc.id}:`, error.message);
    }
  }
  return sent;
}

async function sendVehicleRentAcceptanceNotifications() {
  const cutoff = Date.now() - 30 * 60 * 1000;
  const snapshot = await db.collection("vehicle_rent_requests")
    .where("status", "==", "accepted")
    .get();
  let sent = 0;

  for (const doc of snapshot.docs) {
    const data = doc.data();
    if (data.notificationSentAt) continue;
    const updated = data.ownerUpdatedAt?.toDate?.();
    if (!updated || updated.getTime() < cutoff) continue;
    const customerId = String(data.customerId || "").trim();
    if (!customerId) continue;

    const tokenDoc = await db.collection("user_notification_tokens").doc(customerId).get();
    const token = String(tokenDoc.data()?.token || "").trim();
    if (!token) continue;
    const vehicle = String(data.vehicleType || "Vehicle");
    const finalPrice = data.finalPrice ?? data.total ?? "";

    try {
      await admin.messaging().send({
        token,
        notification: {
          title: "Driver On Call 🚗",
          body: finalPrice ? `${vehicle} booking accepted. Final price ₹${finalPrice}.` : `${vehicle} booking accepted.`,
        },
        data: { type: "vehicle_rent_accepted", bookingId: doc.id, status: "accepted" },
        android: { priority: "high" },
      });
      await doc.ref.update({ notificationSentAt: admin.firestore.FieldValue.serverTimestamp() });
      sent++;
    } catch (error) {
      console.error(`Vehicle-rent notification failed for ${doc.id}:`, error.message);
    }
  }
  return sent;
}

async function main() {
  const driverSent = await sendDriverRequestNotifications();
  const customerSent = await sendCustomerAcceptanceNotifications();
  const rentSent = await sendVehicleRentAcceptanceNotifications();
  console.log(`Completed. Driver requests: ${driverSent}; customer accepts: ${customerSent}; vehicle-rent accepts: ${rentSent}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
