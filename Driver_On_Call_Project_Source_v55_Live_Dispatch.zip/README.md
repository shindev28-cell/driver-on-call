# Driver On Call — v55

Based on v54 Pro Phone OTP Fixed.

### V55 changes
- Live Driver On Call dispatch flow retained.
- Driver request acceptance is now race-safe using a Firestore transaction, so two drivers cannot both successfully accept the same pending request.
- Driver requests carry `requestType: driver_on_call`.
- Customer phone is stored in normalized 10-digit format.
- FCM notification worker sends a new Driver On Call request notification to eligible online drivers.
- FCM notification worker sends a customer notification when a driver accepts.
- Existing Phone OTP, Firebase Auth, FCM token registration and Razorpay payment flow are retained.

### Firestore notification collections
- `user_notification_tokens/{uid}` — FCM token.
- `driver_request_notifications/{requestId}/deliveries/{driverUid}` — per-driver delivery marker.

### Important
The GitHub Actions build workflow must extract this v55 ZIP. The FCM workflow requires the `FIREBASE_SERVICE_ACCOUNT_JSON` GitHub secret.
