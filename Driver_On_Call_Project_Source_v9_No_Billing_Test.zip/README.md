# Driver On Call – v9 No-Billing Testing Login

This source is based on v8 and keeps the existing Driver On Call / Vehicle Rent screens.

## Login change
Firebase Phone Authentication requires the Blaze plan for real SMS verification. This v9 testing build avoids that billing requirement:

- User enters a 10-digit mobile number.
- App shows a **demo OTP: 123456**.
- On correct OTP, the app uses Firebase Anonymous Authentication (free).
- No real SMS is sent.

**Important:** This is for testing the app flow only. A fixed OTP is not secure for production. For production mobile verification, replace this with a real OTP provider or Firebase Phone Auth on Blaze.

## Firebase setup
In Firebase Console:
Authentication → Sign-in method → Anonymous → Enable → Save.

No APK rebuild is needed just to enable Anonymous Auth; after enabling it, the v9 APK can log in.
