# Driver On Call – v9 No-Billing Testing Login

This source is based on v8 and keeps the existing Driver On Call / Vehicle Rent screens.

## Login change
Firebase Phone Authentication requires the Blaze plan for real SMS verification. This v9 testing build avoids that billing requirement:

- User enters a 10-digit mobile number.
- App shows a **demo OTP: 123456**.
- On correct OTP, the app uses Firebase Anonymous Authentication (free).
- No real SMS is sent.

**Important:** This is for testing the app flow only. A fixed OTP is not secure for production. For production mobile verification, replace this with a real OTP provider or Firebase Phone Auth on Blaze.

## Firebase setup
In Firebase Console:
Authentication → Sign-in method → Anonymous → Enable → Save.

No APK rebuild is needed just to enable Anonymous Auth; after enabling it, the v9 APK can log in.


## v10 Booking Details Complete
Vehicle Rent requests now save the Firebase anonymous user's `customerId`.
Customers can open **Vehicle Rent Status** to see the latest request status.
When an owner changes `pending` to `accepted`, the customer sees **Vehicle Confirmed**.
This is still a development/testing build; production Firestore security rules and real user roles are required.

## v11 - Complete Vehicle Rent Booking Details
- Accepted Vehicle Rent bookings now open a full Booking Details screen.
- Shows status, vehicle/service, pickup location, start date, rental duration, estimated price, final price, owner name/mobile, and Booking ID.
- Vehicle Owner Accept opens a confirmation form for owner name, mobile number, and final price before marking the request accepted.


## v12 – Production-style Booking Details UI
- Booking Details now opens directly as a full screen.
- Added confirmed header, booking information, pickup location, start date, duration, estimated/final price.
- Added Vehicle Owner name/mobile card.
- Added Call Owner and Pickup buttons for the testing flow.
- Added copy Booking ID button.
- No new package dependency was added.


## v13 - Booking Details Pro corrected
Fixed Dart class-boundary/update syntax errors from v12 and restored the owner reject helper.


## v15 Customer Booking Status Fix
- Customer Vehicle Rent Status now shows all bookings belonging to the current Firebase user, newest first.
- Accepted bookings show Booking Details for the exact request document.
- This prevents the status screen from hiding an accepted booking when multiple test requests exist.


## v16 – Mandatory Owner Mobile + Real Call
- Vehicle Owner confirmation now requires a valid 10-digit Indian mobile number (6–9 starting).
- Final Price must be greater than ₹0 before confirmation.
- Customer Booking Details `Call Owner` now opens the phone dialer using the saved owner number.
- Added `url_launcher` dependency.
- Existing Vehicle Rent booking/status/details flow is preserved.


## v17 Real Call + Google Maps
- Based on the working v16 Mandatory Owner Mobile source.
- Call Owner opens the phone dialer using the saved owner mobile number.
- Pickup opens Google Maps search for the saved pickup location.
- Owner mobile remains mandatory and final price must be greater than ₹0.


## v18 changes
- Vehicle Rent request now saves the pickup location entered by the customer.
- Pickup Location can be edited before submitting the rental request.
- Booking Details Pickup opens the Google Maps search URL directly without relying on canLaunchUrl, improving Android compatibility.
- Call Owner remains a real phone dialer action.


v19 changes: Fixed Pickup Location dialog lifecycle by moving TextEditingController ownership into a dedicated StatefulWidget. This avoids disposing the controller across the dialog route boundary and fixes the Flutter `_dependents.isEmpty` runtime assertion seen after Save. Google Maps pickup launch from v18 is retained.


v20 fix: Pickup Location dialog no longer manually changes focus before closing, avoiding the Flutter _dependents.isEmpty lifecycle assertion seen on Save.


## v21
Pickup Location editing moved from AlertDialog to a dedicated screen to avoid Flutter overlay/widget deactivation assertion during Save. Google Maps and real Call Owner behavior retained.
