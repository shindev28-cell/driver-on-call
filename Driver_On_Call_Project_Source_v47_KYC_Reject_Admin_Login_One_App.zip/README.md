# Driver On Call — v47

Based on v46 Admin Login One App.

### Included
- Single Main App with Customer / Driver / Vehicle Owner / Admin Login.
- Existing Firebase and driver booking functionality.
- Admin Control WebView.
- Admin Panel source updated with KYC Verify / KYC Reject controls.
- KYC rejection reason saved to Firestore as `kycRejectedReason`.

### Important
The Admin Panel web files must be deployed to GitHub Pages for the new KYC controls to appear inside the app's Admin Control WebView.
