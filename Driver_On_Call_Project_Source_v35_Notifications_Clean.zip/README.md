# Driver On Call — Notifications Clean Master

This clean master preserves the tested Vehicle Rent flow including Pickup/Google Maps, Vehicle Owner dashboard and accept flow, Call Owner, and dynamic Booking History.

## Firebase Cloud Messaging foundation
- firebase_messaging dependency added.
- Android notification permission requested at runtime.
- FCM device token saved to Firestore collection `user_notification_tokens` under the current anonymous Firebase UID.
- Token refresh is saved automatically.
- Background notification payloads are handled by FCM.
- Foreground messages are logged for the current testing phase.

This source does not use flutter_local_notifications, so no core-library-desugaring change is required for the app source.

## Important
Actual cross-device booking notifications still require secure server-side sending (Firebase Cloud Functions or another trusted backend). This source establishes the app-side FCM foundation.

## Build note
The GitHub Actions workflow must remain valid YAML and must extract this ZIP filename exactly when building.
