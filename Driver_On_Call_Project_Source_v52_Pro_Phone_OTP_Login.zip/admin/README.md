# Driver On Call Admin Panel

First MVP: Firebase Email/Password login + dashboard counts + recent vehicle-rent bookings.

Important: this is the first UI build. Before production use, add a proper admin role/custom-claims check and restrictive Firestore rules. Do not expose Firebase service-account credentials in this folder.

Hosting: GitHub Pages can serve `admin/index.html` after Pages is enabled.


## Driver Management v2
The admin dashboard now includes Driver Management backed by the `drivers` Firestore collection.
It can search drivers and write these admin fields without deleting existing driver data:
- `adminApproved` (boolean)
- `adminBlocked` (boolean)
- `adminStatus` (`approved`, `blocked`, or `pending`)
- `updatedByAdmin`
- `updatedAt`

If Firestore rules allow authenticated admin writes, Approve/Block/Unblock will update the driver document.


## KYC Management v3
- KYC Verify sets `kycStatus` to `verified`.
- KYC Reject sets `kycStatus` to `rejected` and stores optional `kycRejectedReason`.
- Admin email and timestamp are stored in `kycUpdatedByAdmin` and `kycUpdatedAt`.
