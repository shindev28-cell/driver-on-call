
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';


@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Notification payloads are displayed automatically by FCM when the app
  // is in the background. Data-only handling can be added later.
}

Future<void> _setupFirebaseMessaging() async {
  try {
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    final token = await messaging.getToken();
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (token != null && uid != null) {
      await FirebaseFirestore.instance
          .collection('user_notification_tokens')
          .doc(uid)
          .set({
        'token': token,
        'updatedAt': FieldValue.serverTimestamp(),
        'platform': 'android',
      }, SetOptions(merge: true));
    }

    messaging.onTokenRefresh.listen((newToken) async {
      final currentUid = FirebaseAuth.instance.currentUser?.uid;
      if (currentUid == null) return;
      try {
        await FirebaseFirestore.instance
            .collection('user_notification_tokens')
            .doc(currentUid)
            .set({
          'token': newToken,
          'updatedAt': FieldValue.serverTimestamp(),
          'platform': 'android',
        }, SetOptions(merge: true));
      } catch (_) {}
    });

    FirebaseMessaging.onMessage.listen((message) {
      debugPrint('FCM foreground message: ${message.notification?.title}');
    });
  } catch (_) {
    // Notifications are optional during testing; never block app startup.
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: 'AIzaSyCKKgG38JlJDjZQbPQC2jdaxIwJ1gZX5V8',
        appId: '1:273781697153:android:1981de83c225a20b10fb80',
        messagingSenderId: '273781697153',
        projectId: 'driver-on-call-d2a72',
        storageBucket: 'driver-on-call-d2a72.firebasestorage.app',
      ),
    );
    FirebaseMessaging.onBackgroundMessage(
      _firebaseMessagingBackgroundHandler,
    );
    if (FirebaseAuth.instance.currentUser != null) {
      await _setupFirebaseMessaging();
    }
  } catch (_) {
    // The app can still open in demo mode if Firebase is unavailable.
  }
  runApp(const DriverOnCall());
}


class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data != null) return const HomeScreen();
        return const PhoneLoginScreen();
      },
    );
  }
}

/// No-billing testing login.
/// Firebase Phone Auth sends real SMS only on a paid Blaze plan, so this
/// version uses a local demo OTP and Firebase Anonymous Auth. It is intended
/// for testing the app flow, not as production identity verification.
class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});

  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final phoneController = TextEditingController();
  final otpController = TextEditingController();
  bool codeSent = false;
  bool loading = false;
  String message = '';

  // Demo-only OTP. Never use a fixed OTP for production authentication.
  static const demoOtp = '123456';

  @override
  void dispose() {
    phoneController.dispose();
    otpController.dispose();
    super.dispose();
  }

  void _sendOtp() {
    final phone = phoneController.text.trim();
    if (!RegExp(r'^\d{10}$').hasMatch(phone)) {
      setState(() => message = 'कृपया 10 अंकी Mobile Number टाका.');
      return;
    }
    setState(() {
      codeSent = true;
      message = 'Testing OTP: 123456  (SMS पाठवला जाणार नाही)';
    });
  }

  Future<void> _verifyOtp() async {
    final otp = otpController.text.trim();
    if (otp != demoOtp) {
      setState(() => message = 'OTP चुकीचा आहे. Testing OTP: 123456');
      return;
    }

    setState(() {
      loading = true;
      message = '';
    });

    try {
      // Anonymous Auth is free and does not require Firebase Blaze billing.
      await FirebaseAuth.instance.signInAnonymously();
      await _setupFirebaseMessaging();
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        message = e.message ??
            'Anonymous Login बंद आहे. Firebase Authentication मध्ये Anonymous provider Enable करा.';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        message = 'Login झाला नाही. पुन्हा प्रयत्न करा.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver On Call Login')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 35),
          const Icon(Icons.phone_android, size: 80),
          const SizedBox(height: 18),
          const Text(
            'Mobile Number ने Login करा',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            'No-billing Testing Login',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17),
          ),
          const SizedBox(height: 28),
          if (!codeSent) ...[
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: const InputDecoration(
                prefixText: '+91 ',
                labelText: 'Mobile Number',
                hintText: '9876543210',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: loading ? null : _sendOtp,
              icon: const Icon(Icons.sms),
              label: const Text('OTP पाठवा'),
            ),
          ] else ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  'Testing OTP: $demoOtp\nहा OTP SMS ने येणार नाही.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 17),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: otpController,
              keyboardType: TextInputType.number,
              maxLength: 6,
              decoration: const InputDecoration(
                labelText: 'OTP',
                hintText: '123456',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: loading ? null : _verifyOtp,
              icon: const Icon(Icons.verified),
              label: Text(loading ? 'Login होत आहे...' : 'OTP Verify करा'),
            ),
            TextButton(
              onPressed: loading
                  ? null
                  : () => setState(() {
                        codeSent = false;
                        message = '';
                        otpController.clear();
                      }),
              child: const Text('Mobile Number बदला'),
            ),
          ],
          if (message.isNotEmpty) ...[
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(message, textAlign: TextAlign.center),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class DriverOnCall extends StatelessWidget {
  const DriverOnCall({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Driver On Call',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5866A3)),
        scaffoldBackgroundColor: const Color(0xFFF9F7FC),
      ),
      home: const AuthGate(),
    );
  }
}

void go(BuildContext c, Widget page) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => page));

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String vehicle = 'Car';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver On Call',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Vehicle Owner',
            icon: const Icon(Icons.car_rental),
            onPressed: () => go(context, const VehicleOwnerDashboard()),
          ),
          IconButton(
            tooltip: 'Driver Mode',
            icon: const Icon(Icons.drive_eta),
            onPressed: () => go(context, const DriverDashboard()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(28, 28, 28, 24),
        children: [
          const Text('नमस्कार! 👋',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('गरज असेल तेव्हा Driver तुमच्या जवळ.',
              style: TextStyle(fontSize: 18)),
          const SizedBox(height: 30),
          _mainButton(context, Icons.flash_on, 'आत्ता Driver हवा', () {
            go(context, const NowBookingScreen());
          }),
          _mainButton(context, Icons.calendar_month, 'Driver Schedule करा', () {
            go(context, const ScheduleBookingScreen());
          }),
          _mainButton(context, Icons.directions_car, '🚗 Vehicle Rent', () {
            go(context, const VehicleRentScreen());
          }),
          _mainButton(context, Icons.history, '📋 माझ्या Bookings', () {
            go(context, const BookingHistoryScreen());
          }),
          _mainButton(context, Icons.car_rental, '🏢 Vehicle Owner', () {
            go(context, const VehicleOwnerDashboard());
          }),
          const SizedBox(height: 14),
          Card(
            elevation: 1,
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              leading: const Icon(Icons.location_on, size: 30),
              title: const Text('Pickup Location',
                  style: TextStyle(fontSize: 19)),
              subtitle: const Text('Current location (demo)',
                  style: TextStyle(fontSize: 16)),
              trailing: IconButton(
                icon: const Icon(Icons.edit_location_alt),
                onPressed: () => _locationDialog(context),
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Text('वाहनाचा प्रकार',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: ['Car', 'SUV', 'Other'].map((v) {
              return ChoiceChip(
                label: Text(v == 'Car' ? '🚗 Car' : v == 'SUV' ? '🚙 SUV' : '🛻 Other'),
                selected: vehicle == v,
                onSelected: (_) => setState(() => vehicle = v),
              );
            }).toList(),
          ),
          const SizedBox(height: 22),
          _menuCard(context, Icons.car_rental, 'Vehicle Rent Status',
              () => go(context, const VehicleRentStatusScreen())),
          _menuCard(context, Icons.support_agent, 'Help & Support',
              () => go(context, const SupportScreen())),
        ],
      ),
    );
  }

  Widget _mainButton(BuildContext c, IconData icon, String text, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(64),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        onPressed: tap,
        icon: Icon(icon, size: 30),
        label: Text(text, style: const TextStyle(fontSize: 21)),
      ),
    );
  }

  Widget _menuCard(
      BuildContext c, IconData icon, String title, VoidCallback tap) {
    return Card(
      child: ListTile(
        leading: Icon(icon, size: 30),
        title: Text(title, style: const TextStyle(fontSize: 19)),
        trailing: const Icon(Icons.chevron_right),
        onTap: tap,
      ),
    );
  }

  void _locationDialog(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('Pickup Location'),
        content: const Text(
            'Vehicle Rent मध्ये Pickup Location म्हणून तुमचे ठिकाण टाका. Booking Details मधील Pickup बटण ते ठिकाण Google Maps मध्ये उघडेल.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('OK'))
        ],
      ),
    );
  }
}

class PickupLocationEditScreen extends StatefulWidget {
  final String initialValue;

  const PickupLocationEditScreen({super.key, required this.initialValue});

  @override
  State<PickupLocationEditScreen> createState() => _PickupLocationEditScreenState();
}

class _PickupLocationEditScreenState extends State<PickupLocationEditScreen> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    final value = _controller.text.trim();
    if (value.isEmpty) return;
    Navigator.of(context).pop(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pickup Location'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Pickup ठिकाण',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _controller,
              autofocus: true,
              maxLines: 2,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _save(),
              decoration: const InputDecoration(
                hintText: 'उदा. Barshi ST Stand, Solapur',
                labelText: 'Pickup Location',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.check),
              label: const Text('सेव्ह'),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
            ),
          ],
        ),
      ),
    );
  }
}

class VehicleRentScreen extends StatefulWidget {
  const VehicleRentScreen({super.key});
  @override
  State<VehicleRentScreen> createState() => _VehicleRentScreenState();
}

class _VehicleRentScreenState extends State<VehicleRentScreen> {
  String service = 'Only Vehicle';
  String vehicleType = 'Car';
  int days = 1;
  DateTime startDate = DateTime.now();
  String pickupLocation = 'Current location (demo)';

  int get dailyRate {
    if (vehicleType == 'SUV') return service == 'Vehicle + Driver' ? 3500 : 2800;
    if (vehicleType == 'Tempo Traveller') {
      return service == 'Vehicle + Driver' ? 5000 : 4200;
    }
    return service == 'Vehicle + Driver' ? 2500 : 1800;
  }

  int get total => dailyRate * days;

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: startDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => startDate = picked);
  }

  Future<void> _editPickupLocation() async {
    final result = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => PickupLocationEditScreen(
          initialValue:
              pickupLocation == 'Current location (demo)' ? '' : pickupLocation,
        ),
      ),
    );
    if (result != null && result.isNotEmpty && mounted) {
      setState(() => pickupLocation = result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateText = '${startDate.day.toString().padLeft(2, '0')}/'
        '${startDate.month.toString().padLeft(2, '0')}/${startDate.year}';

    return Scaffold(
      appBar: AppBar(title: const Text('🚗 Vehicle Rent')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          const Text('तुम्हाला वाहन कसे हवे?',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'Only Vehicle', label: Text('🚗 Only Vehicle')),
              ButtonSegment(value: 'Vehicle + Driver', label: Text('👨‍✈️ + Driver')),
            ],
            selected: {service},
            onSelectionChanged: (v) => setState(() => service = v.first),
          ),
          const SizedBox(height: 24),
          const Text('वाहन निवडा',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...['Car', 'SUV', 'Tempo Traveller'].map((v) => Card(
                child: RadioListTile<String>(
                  value: v,
                  groupValue: vehicleType,
                  onChanged: (value) => setState(() => vehicleType = value!),
                  title: Text(v == 'Car'
                      ? '🚗 Car'
                      : v == 'SUV'
                          ? '🚙 SUV'
                          : '🚐 Tempo Traveller'),
                  subtitle: Text('₹${v == 'Car' ? 1800 : v == 'SUV' ? 2800 : 4200} / दिवसापासून'),
                ),
              )),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.calendar_month, size: 30),
              title: const Text('Start Date'),
              subtitle: Text(dateText),
              trailing: OutlinedButton(
                onPressed: _pickDate,
                child: const Text('बदला'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.location_on, size: 30),
              title: const Text('Pickup Location', style: TextStyle(fontSize: 18)),
              subtitle: Text(pickupLocation, style: const TextStyle(fontSize: 16)),
              trailing: OutlinedButton.icon(
                onPressed: _editPickupLocation,
                icon: const Icon(Icons.edit_location_alt),
                label: const Text('बदला'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Text('किती दिवस?', style: TextStyle(fontSize: 18)),
                  ),
                  IconButton(
                    onPressed: days > 1 ? () => setState(() => days--) : null,
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text('$days',
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  IconButton(
                    onPressed: days < 30 ? () => setState(() => days++) : null,
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            elevation: 1,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$vehicleType • $service',
                      style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 8),
                  Text('₹$dailyRate × $days दिवस',
                      style: const TextStyle(fontSize: 16)),
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('अंदाजे एकूण',
                          style: TextStyle(
                              fontSize: 19, fontWeight: FontWeight.bold)),
                      Text('₹$total',
                          style: const TextStyle(
                              fontSize: 25, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text('Final price availability आणि admin rates नुसार बदलू शकतो.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => _submitRentRequest(context, dateText),
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Vehicle Rent Request करा',
                style: TextStyle(fontSize: 18)),
          ),
        ],
      ),
    );
  }
  Future<void> _submitRentRequest(BuildContext context, String dateText) async {
    final data = {
      'service': service,
      'vehicleType': vehicleType,
      'startDate': Timestamp.fromDate(startDate),
      'days': days,
      'dailyRate': dailyRate,
      'total': total,
      'pickupLocation': pickupLocation,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'customerName': 'Guest Customer',
      'customerId': FirebaseAuth.instance.currentUser?.uid ?? '',
    };

    String message = 'Request तयार झाली आहे. Vehicle Owner कडून confirmation येईल.';
    String? requestId;
    try {
      final ref = await FirebaseFirestore.instance
          .collection('vehicle_rent_requests')
          .add(data);
      requestId = ref.id;
    } catch (_) {
      message = 'Request demo mode मध्ये तयार झाली. Firebase permission/auth सेट केल्यावर ती Owner ला live दिसेल.';
    }

    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Vehicle Rent Request 🚗'),
        content: Text(
          '$vehicleType • $service\n$dateText पासून $days दिवस\nअंदाजे ₹$total\n\n$message'
          '${requestId == null ? '' : '\n\nRequest ID: $requestId'}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('ठीक आहे'),
          ),
          if (requestId != null)
            FilledButton(
              onPressed: () {
                Navigator.pop(context);
                go(context, const VehicleRentStatusScreen());
              },
              child: const Text('Status पाहा'),
            ),
        ],
      ),
    );
  }
}

class VehicleRentStatusScreen extends StatelessWidget {
  const VehicleRentStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Vehicle Rent Status')),
      body: uid.isEmpty
          ? const Center(child: Text('Login session सापडली नाही.'))
          : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('vehicle_rent_requests')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Booking status पाहता आला नाही. Firebase permission तपासा.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data?.docs
                        .where((doc) => (doc.data()['customerId'] ?? '') == uid)
                        .toList() ??
                    [];

                if (docs.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'तुमची Vehicle Rent booking अजून उपलब्ध नाही.\n\nनवीन request केल्यावर तिचा status इथे दिसेल.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 19),
                      ),
                    ),
                  );
                }

                docs.sort((a, b) {
                  final at = a.data()['createdAt'];
                  final bt = b.data()['createdAt'];
                  if (at is Timestamp && bt is Timestamp) {
                    return bt.compareTo(at);
                  }
                  if (at is Timestamp) return -1;
                  if (bt is Timestamp) return 1;
                  return b.id.compareTo(a.id);
                });

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final d = <String, dynamic>{
                      ...doc.data(),
                      'requestId': doc.id,
                    };
                    final status = (d['status'] ?? 'pending').toString();
                    final vehicle = (d['vehicleType'] ?? 'Vehicle').toString();
                    final service = (d['service'] ?? 'Only Vehicle').toString();
                    final total = (d['total'] ?? 0).toString();
                    final finalPrice = d['finalPrice'];
                    final days = (d['days'] ?? 1).toString();
                    final accepted = status == 'accepted';
                    final rejected = status == 'rejected';

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Card(
                        elevation: 2,
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            children: [
                              Icon(
                                accepted
                                    ? Icons.check_circle
                                    : rejected
                                        ? Icons.cancel
                                        : Icons.hourglass_top,
                                size: 62,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                accepted
                                    ? 'Vehicle Confirmed ✅'
                                    : rejected
                                        ? 'Request Rejected'
                                        : 'Confirmation Pending ⏳',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 23,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(
                                '$vehicle • $service',
                                style: const TextStyle(fontSize: 20),
                              ),
                              const SizedBox(height: 7),
                              Text('₹$total • $days दिवस'),
                              if (accepted && finalPrice != null) ...[
                                const SizedBox(height: 5),
                                Text(
                                  'Final Price: ₹$finalPrice',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                              const SizedBox(height: 12),
                              Text(
                                accepted
                                    ? 'Vehicle Owner ने तुमची booking स्वीकारली आहे.'
                                    : rejected
                                        ? 'Vehicle Owner ने ही request नाकारली आहे.'
                                        : 'Vehicle Owner कडून confirmation ची वाट पाहत आहोत.',
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 16),
                              ),
                              if (accepted) ...[
                                const SizedBox(height: 14),
                                SizedBox(
                                  width: double.infinity,
                                  child: FilledButton.icon(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              VehicleRentBookingDetailsScreen(
                                            data: d,
                                          ),
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.verified),
                                    label: const Text('Booking Details उघडा'),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class NowBookingScreen extends StatefulWidget {
  const NowBookingScreen({super.key});
  @override State<NowBookingScreen> createState() => _NowBookingScreenState();
}

class _NowBookingScreenState extends State<NowBookingScreen> {
  String duration = '4 तास';
  String purpose = 'माझी गाडी Driver ने चालवावी';
  String vehicle = 'Car';

  @override
  Widget build(BuildContext context) {
    final fare = vehicle == 'SUV' ? 1200 : vehicle == 'Other' ? 1050 : 900;
    return Scaffold(
      appBar: AppBar(title: const Text('आता Driver हवा')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _section('📍 Pickup Location',
              const Text('Current location (demo)')),
          _section('🚗 वाहनाचा प्रकार',
              DropdownButtonFormField<String>(
                value: vehicle,
                items: ['Car', 'SUV', 'Other']
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() => vehicle = v!),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              )),
          _section('Driver कशासाठी हवा?',
              DropdownButtonFormField<String>(
                value: purpose,
                items: [
                  'माझी गाडी Driver ने चालवावी',
                  'Driver सोबत वाहन हवे'
                ]
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() => purpose = v!),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              )),
          _section('⏱️ किती वेळासाठी?',
              Wrap(
                spacing: 8,
                children: ['2 तास', '4 तास', '8 तास', 'पूर्ण दिवस']
                    .map((v) => ChoiceChip(
                          label: Text(v),
                          selected: duration == v,
                          onSelected: (_) => setState(() => duration = v),
                        ))
                    .toList(),
              )),
          Card(
            child: ListTile(
              title: const Text('अंदाजे भाडे'),
              trailing: Text('₹$fare',
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold)),
              subtitle: const Text('Admin fare settings नुसार estimate'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.flash_on),
            label: const Text('Driver शोधा',
                style: TextStyle(fontSize: 19)),
            onPressed: () async {
              final user = FirebaseAuth.instance.currentUser;
              if (user == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('कृपया आधी Login करा.')),
                );
                return;
              }
              try {
                final ref = await FirebaseFirestore.instance
                    .collection('driver_requests')
                    .add({
                  'customerId': user.uid,
                  'customerName': user.displayName ?? 'Customer',
                  'customerPhone': user.phoneNumber ?? '',
                  'vehicle': vehicle,
                  'duration': duration,
                  'fare': fare,
                  'pickupLocation': 'Current location (demo)',
                  'status': 'pending',
                  'driverId': null,
                  'driverName': null,
                  'driverPhone': null,
                  'createdAt': FieldValue.serverTimestamp(),
                  'updatedAt': FieldValue.serverTimestamp(),
                });
                if (!mounted) return;
                go(context, SearchingDriverScreen(
                  requestId: ref.id,
                  vehicle: vehicle,
                  duration: duration,
                  fare: fare,
                ));
              } on FirebaseException catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(
                      'Driver request save झाला नाही: ${e.message ?? e.code}')),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _section(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            child,
          ],
        ),
      );
}

class SearchingDriverScreen extends StatelessWidget {
  final String requestId;
  final String vehicle, duration;
  final int fare;

  const SearchingDriverScreen({
    super.key,
    required this.requestId,
    required this.vehicle,
    required this.duration,
    required this.fare,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver शोधत आहे')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('driver_requests')
            .doc(requestId)
            .snapshots(),
        builder: (context, snapshot) {
          final d = snapshot.data?.data() ?? {};
          final status = (d['status'] ?? 'pending').toString();
          final driverName = (d['driverName'] ?? '').toString();

          if (status == 'accepted' && driverName.isNotEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircleAvatar(
                      radius: 42,
                      child: Icon(Icons.check, size: 48),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Driver मिळाला! ✅',
                      style: TextStyle(
                          fontSize: 25, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Text(driverName,
                        style: const TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text(
                        '${d['vehicleType'] ?? vehicle} • ${d['driverPhone'] ?? ''}'),
                    const SizedBox(height: 22),
                    FilledButton.icon(
                      onPressed: () => go(context, const AssignedScreen()),
                      icon: const Icon(Icons.person),
                      label: const Text('Driver Details'),
                    ),
                  ],
                ),
              ),
            );
          }

          if (status == 'rejected' || status == 'cancelled') {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.close, size: 60),
                    const SizedBox(height: 15),
                    Text(
                      status == 'rejected'
                          ? 'Driver request नाकारली.'
                          : 'Driver request cancelled.',
                      style: const TextStyle(fontSize: 20),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            );
          }

          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 25),
                  const Text(
                    'जवळचा Online Driver शोधत आहे...',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text('$vehicle • $duration • अंदाजे ₹$fare'),
                  const SizedBox(height: 25),
                  const Text(
                    'Online Driver request accept करेपर्यंत थांबा.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class AssignedScreen extends StatelessWidget {
  const AssignedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Confirmed ✅')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const CircleAvatar(radius: 52, child: Icon(Icons.person, size: 56)),
            const SizedBox(height: 12),
            const Center(
                child: Text('Raj Patil',
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
            const Center(child: Text('⭐ 4.8  •  ✓ Verified Driver')),
            const SizedBox(height: 18),
            Card(
              child: Column(children: [
                const ListTile(
                    leading: Icon(Icons.directions_car),
                    title: Text('Car'),
                    subtitle: Text('MH-XX-1234')),
                ListTile(
                    leading: const Icon(Icons.location_on),
                    title: const Text('ETA'),
                    subtitle: const Text('8 minutes • Live location (demo)')),
                ListTile(
                    leading: const Icon(Icons.phone),
                    title: const Text('Call Driver'),
                    onTap: () {}),
              ]),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => go(context, const TripScreen()),
              child: const Text('START / VIEW TRIP'),
            ),
            OutlinedButton(
              onPressed: () => _cancel(context),
              child: const Text('CANCEL BOOKING'),
            ),
          ],
        ),
      );

  void _cancel(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('Booking Cancel करायची?'),
        content: const Text('Cancellation rules पुढील build मध्ये लागू होतील.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('No')),
          FilledButton(
              onPressed: () {
                Navigator.pop(c);
                ScaffoldMessenger.of(c).showSnackBar(
                    const SnackBar(content: Text('Booking cancelled')));
              },
              child: const Text('Cancel')),
        ],
      ),
    );
  }
}

class TripScreen extends StatelessWidget {
  const TripScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Trip in Progress')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.navigation, size: 90),
              const SizedBox(height: 18),
              const Text('Trip सुरू आहे',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Live Location (demo)'),
              const SizedBox(height: 28),
              FilledButton(
                onPressed: () => go(context, const PaymentScreen()),
                child: const Text('END TRIP'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => _sos(context),
                icon: const Icon(Icons.emergency),
                label: const Text('🚨 EMERGENCY HELP'),
              ),
            ]),
          ),
        ),
      );

  void _sos(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('🚨 Emergency'),
        content: const Text(
            'Emergency Call, Share Location किंवा Support यापैकी पर्याय निवडा.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close')),
        ],
      ),
    );
  }
}

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Payment')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Text('Final Fare'),
            const Text('₹900',
                style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: const Icon(Icons.account_balance_wallet),
                title: const Text('UPI / Online Payment'),
                onTap: () {},
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.payments),
                title: const Text('Cash'),
                onTap: () {},
              ),
            ),
            const Spacer(),
            FilledButton(
              onPressed: () => go(context, const RatingScreen()),
              child: const Text('PAY & CONTINUE'),
            ),
          ]),
        ),
      );
}


class VehicleRentPaymentScreen extends StatefulWidget {
  final Map<String, dynamic> data;
  const VehicleRentPaymentScreen({super.key, required this.data});

  @override
  State<VehicleRentPaymentScreen> createState() => _VehicleRentPaymentScreenState();
}

class _VehicleRentPaymentScreenState extends State<VehicleRentPaymentScreen> {
  late final Razorpay _razorpay;
  DocumentReference<Map<String, dynamic>>? _paymentRef;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _paymentSub;
  bool _starting = false;
  bool _checkoutOpened = false;
  String _message = 'Razorpay Test Payment तयार आहे.';

  double get _amount {
    final raw = widget.data['finalPrice'] ?? widget.data['total'] ?? 0;
    return double.tryParse(raw.toString()) ?? 0;
  }

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _paymentSub?.cancel();
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _startPayment() async {
    if (_starting || _amount <= 0) return;
    setState(() {
      _starting = true;
      _message = 'Payment order तयार होत आहे...';
    });

    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Customer login required');

      final bookingId = (widget.data['requestId'] ?? '').toString();
      final ref = await FirebaseFirestore.instance.collection('payment_requests').add({
        'bookingId': bookingId,
        'customerId': uid,
        'amount': _amount.round(),
        'currency': 'INR',
        'status': 'created',
        'createdAt': FieldValue.serverTimestamp(),
      });
      _paymentRef = ref;

      _paymentSub = ref.snapshots().listen((snap) {
        final d = snap.data();
        if (!mounted || d == null) return;
        final orderId = (d['orderId'] ?? '').toString();
        final status = (d['status'] ?? '').toString();
        if (status == 'paid') {
          setState(() {
            _starting = false;
            _message = 'Payment successful ✅';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Payment successful ✅')),
          );
          return;
        }
        if (status == 'failed') {
          setState(() {
            _starting = false;
            _message = 'Payment failed. पुन्हा प्रयत्न करा.';
          });
          return;
        }
        if (orderId.isNotEmpty && status == 'order_created' && !_checkoutOpened) {
          _checkoutOpened = true;
          _openCheckout(orderId);
        }
      });
    } catch (e) {
      setState(() {
        _starting = false;
        _message = 'Payment सुरू करता आले नाही.';
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Payment error: $e')),
        );
      }
    }
  }

  void _openCheckout(String orderId) {
    final options = {
      'key': 'rzp_test_TacO0vgJl6zzLm',
      'amount': (_amount * 100).round(),
      'currency': 'INR',
      'name': 'Driver On Call',
      'description': 'Vehicle Rent Booking',
      'order_id': orderId,
      'timeout': 300,
      'prefill': {
        'name': 'Driver On Call Customer',
      },
    };
    try {
      _razorpay.open(options);
    } catch (e) {
      setState(() {
        _starting = false;
        _message = 'Razorpay checkout उघडता आले नाही.';
      });
    }
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final ref = _paymentRef;
    if (ref == null) return;
    await ref.update({
      'status': 'payment_submitted',
      'paymentId': response.paymentId,
      'razorpayOrderId': response.orderId,
      'signature': response.signature,
      'submittedAt': FieldValue.serverTimestamp(),
    });
    if (mounted) {
      setState(() => _message = 'Payment verify होत आहे...');
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    setState(() {
      _starting = false;
      _message = 'Payment cancelled/failed.';
    });
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    setState(() => _message = 'External wallet निवडले आहे.');
  }

  @override
  Widget build(BuildContext context) {
    final vehicle = (widget.data['vehicleType'] ?? 'Vehicle').toString();
    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(Icons.lock, size: 48),
                  const SizedBox(height: 10),
                  const Text('Razorpay Test Payment', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(vehicle),
                  const SizedBox(height: 14),
                  Text('₹${_amount.toStringAsFixed(0)}', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Text(_message, textAlign: TextAlign.center),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _starting ? null : _startPayment,
            icon: const Icon(Icons.payment),
            label: Text(_starting ? 'PROCESSING...' : 'PAY WITH RAZORPAY'),
          ),
          const SizedBox(height: 10),
          const Text(
            'हा Test Mode आहे. Real पैसे कापले जाणार नाहीत.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }
}

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});
  @override State<RatingScreen> createState() => _RatingScreenState();
}
class _RatingScreenState extends State<RatingScreen> {
  int rating = 5;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Rate Driver')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Trip कसा होता?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                    5,
                    (i) => IconButton(
                          iconSize: 42,
                          onPressed: () => setState(() => rating = i + 1),
                          icon: Icon(
                              i < rating ? Icons.star : Icons.star_border),
                        ))),
            const SizedBox(height: 15),
            const TextField(
                maxLines: 3,
                decoration: InputDecoration(
                    hintText: 'Feedback लिहा',
                    border: OutlineInputBorder())),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
              child: const Text('SUBMIT'),
            )
          ]),
        ),
      );
}

class _VehicleRentPaymentStatusCard extends StatefulWidget {
  final String requestId;
  final Map<String, dynamic> bookingData;

  const _VehicleRentPaymentStatusCard({
    required this.requestId,
    required this.bookingData,
  });

  @override
  State<_VehicleRentPaymentStatusCard> createState() =>
      _VehicleRentPaymentStatusCardState();
}

class _VehicleRentPaymentStatusCardState
    extends State<_VehicleRentPaymentStatusCard> {
  Timer? _timer;
  bool _paid = false;
  bool _checking = true;

  @override
  void initState() {
    super.initState();
    _refreshPaymentStatus();
    // GitHub Actions worker can update Firestore after this screen is already open.
    // Poll briefly so the PAID badge appears without needing a new APK launch.
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (!_paid) _refreshPaymentStatus();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refreshPaymentStatus() async {
    final id = widget.requestId.trim();
    if (id.isEmpty || id == '—') return;

    try {
      final bookingSnap = await FirebaseFirestore.instance
          .collection('vehicle_rent_requests')
          .doc(id)
          .get(const GetOptions(source: Source.server));
      final bookingStatus =
          (bookingSnap.data()?['paymentStatus'] ?? '').toString().toLowerCase();

      bool paid = bookingStatus == 'paid';

      if (!paid) {
        final paymentSnap = await FirebaseFirestore.instance
            .collection('payment_requests')
            .where('bookingId', isEqualTo: id)
            .limit(10)
            .get(const GetOptions(source: Source.server));
        paid = paymentSnap.docs.any((doc) {
          return (doc.data()['status'] ?? '').toString().toLowerCase() == 'paid';
        });
      }

      if (!mounted) return;
      setState(() {
        _paid = paid;
        _checking = false;
      });
      if (paid) _timer?.cancel();
    } catch (_) {
      if (!mounted) return;
      setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              '💳 Payment',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (_paid) ...[
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(width: 1.5),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.check_circle, size: 30),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'PAID ✅\nPayment successful',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ] else if (_checking) ...[
              const Text('Payment status तपासत आहे...'),
              const SizedBox(height: 12),
              const LinearProgressIndicator(),
            ] else ...[
              const Text('Final price साठी Razorpay Test Checkout वापरा.'),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () => go(
                  context,
                  VehicleRentPaymentScreen(data: widget.bookingData),
                ),
                icon: const Icon(Icons.payment),
                label: const Text('PAY NOW'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class ScheduleBookingScreen extends StatefulWidget {
  const ScheduleBookingScreen({super.key});
  @override State<ScheduleBookingScreen> createState() =>
      _ScheduleBookingScreenState();
}
class _ScheduleBookingScreenState extends State<ScheduleBookingScreen> {
  DateTime date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay time = const TimeOfDay(hour: 9, minute: 0);
  String vehicle = 'Car';
  String duration = '4 तास';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver Schedule करा')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: const Text('तारीख'),
            subtitle: Text('${date.day}/${date.month}/${date.year}'),
            onTap: () async {
              final d = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 90)),
                  initialDate: date);
              if (d != null) setState(() => date = d);
            },
          ),
          ListTile(
            leading: const Icon(Icons.access_time),
            title: const Text('वेळ'),
            subtitle: Text(time.format(context)),
            onTap: () async {
              final t = await showTimePicker(context: context, initialTime: time);
              if (t != null) setState(() => time = t);
            },
          ),
          DropdownButtonFormField<String>(
            value: vehicle,
            items: ['Car', 'SUV', 'Other']
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
            onChanged: (v) => setState(() => vehicle = v!),
            decoration: const InputDecoration(
                labelText: 'वाहनाचा प्रकार', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: duration,
            items: ['2 तास', '4 तास', '8 तास', 'पूर्ण दिवस']
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
            onChanged: (v) => setState(() => duration = v!),
            decoration: const InputDecoration(
                labelText: 'Duration', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 20),
          Card(
            child: const ListTile(
              title: Text('Estimated Fare'),
              trailing: Text('₹900',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Admin fare settings नुसार'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.event_available),
            label: const Text('Booking Schedule करा'),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Booking Scheduled ✅')));
            },
          )
        ],
      ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class BookingHistoryScreen extends StatelessWidget {
  const BookingHistoryScreen({super.key});

  String _dateTimeText(dynamic value) {
    if (value is Timestamp) {
      final d = value.toDate().toLocal();
      final date = '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
      final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
      final minute = d.minute.toString().padLeft(2, '0');
      final ampm = d.hour >= 12 ? 'PM' : 'AM';
      return '$date • $hour:$minute $ampm';
    }
    return value?.toString() ?? '—';
  }

  String _dateText(dynamic value) {
    if (value is Timestamp) {
      final d = value.toDate().toLocal();
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    }
    return value?.toString() ?? '—';
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    if (uid.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('माझ्या Bookings')),
        body: const Center(child: Text('Login session सापडली नाही.')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('माझ्या Bookings')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('vehicle_rent_requests').snapshots(),
        builder: (context, vehicleSnap) {
          if (vehicleSnap.hasError) {
            return const Center(child: Text('Booking History पाहता आली नाही. Firebase permission तपासा.'));
          }
          if (vehicleSnap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('driver_requests').snapshots(),
            builder: (context, driverSnap) {
              if (driverSnap.hasError) {
                return const Center(child: Text('Driver Booking History पाहता आली नाही. Firebase permission तपासा.'));
              }
              if (driverSnap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              final items = <Map<String, dynamic>>[];
              for (final doc in vehicleSnap.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[]) {
                final d = doc.data();
                if ((d['customerId'] ?? '') != uid) continue;
                items.add({...d, 'requestId': doc.id, '_kind': 'vehicle'});
              }
              for (final doc in driverSnap.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[]) {
                final d = doc.data();
                if ((d['customerId'] ?? '') != uid) continue;
                items.add({...d, 'requestId': doc.id, '_kind': 'driver'});
              }

              items.sort((a, b) {
                final at = a['bookingDateTime'] ?? a['createdAt'];
                final bt = b['bookingDateTime'] ?? b['createdAt'];
                if (at is Timestamp && bt is Timestamp) return bt.compareTo(at);
                if (at is Timestamp) return -1;
                if (bt is Timestamp) return 1;
                return b['requestId'].toString().compareTo(a['requestId'].toString());
              });

              if (items.isEmpty) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'तुमची Booking History अजून रिकामी आहे.\n\nनवीन Booking केल्यावर ती इथे दिसेल.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 19),
                    ),
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(14),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final d = items[index];
                  final isDriver = d['_kind'].toString() == 'driver';
                  final status = (d['status'] ?? 'pending').toString().toLowerCase();
                  final accepted = status == 'accepted';
                  final rejected = status == 'rejected';
                  final vehicle = (d['vehicleType'] ?? d['vehicle'] ?? 'Vehicle').toString();
                  final service = isDriver ? 'Driver On Call' : (d['service'] ?? 'Only Vehicle').toString();
                  final pickup = (d['pickupLocation'] ?? '—').toString();
                  final total = (d['total'] ?? d['fare'] ?? 0).toString();
                  final days = (d['days'] ?? 1).toString();
                  final bookingWhen = _dateTimeText(d['bookingDateTime'] ?? d['createdAt']);
                  final statusText = accepted ? 'ACCEPTED ✅' : rejected ? 'REJECTED ❌' : 'PENDING ⏳';

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(isDriver ? Icons.person : Icons.directions_car, size: 30),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text('$vehicle • $service', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                              ),
                              Text(statusText, style: const TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text('🗓️ Booking Date & Time: $bookingWhen', style: const TextStyle(fontWeight: FontWeight.w700)),
                          if (!isDriver && d['startDate'] != null) ...[
                            const SizedBox(height: 5),
                            Text('📅 Start Date: ${_dateText(d['startDate'])} • $days दिवस'),
                          ],
                          const SizedBox(height: 5),
                          Text('📍 $pickup', style: const TextStyle(fontSize: 16)),
                          const SizedBox(height: 5),
                          Text('💰 Estimated: ₹$total'),
                          if (isDriver && accepted) ...[
                            const SizedBox(height: 8),
                            Text('👨‍✈️ Driver: ${(d['driverName'] ?? 'Driver').toString()}', style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text('📞 ${(d['driverPhone'] ?? '—').toString()}'),
                          ],
                          if (!isDriver && accepted) ...[
                            const SizedBox(height: 7),
                            Builder(
                              builder: (_) {
                                final paymentStatus = (d['paymentStatus'] ?? 'unpaid').toString().toLowerCase();
                                return Text(paymentStatus == 'paid' ? '💳 Payment: PAID ✅' : '💳 Payment: PENDING', style: const TextStyle(fontWeight: FontWeight.w700));
                              },
                            ),
                          ],
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Help & Support')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('काय समस्या आहे?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...[
              'Driver संबंधित समस्या',
              'Payment समस्या',
              'Booking समस्या',
              'Cancellation समस्या',
              'Safety समस्या',
              'इतर समस्या'
            ].map((x) => Card(
                  child: ListTile(
                    title: Text(x),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _ticket(context, x),
                  ),
                )),
          ],
        ),
      );

  void _ticket(BuildContext c, String category) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(category),
        content: const TextField(
          maxLines: 4,
          decoration: InputDecoration(
              hintText: 'तुमची समस्या लिहा...',
              border: OutlineInputBorder()),
        ),
        actions: [
          FilledButton(
              onPressed: () {
                Navigator.pop(c);
                ScaffoldMessenger.of(c).showSnackBar(
                    const SnackBar(content: Text('Complaint submitted ✅')));
              },
              child: const Text('Submit'))
        ],
      ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V6
class VehicleOwnerDashboard extends StatelessWidget {
  const VehicleOwnerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vehicle Owner Dashboard')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('vehicle_rent_requests')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return ListView(
              padding: const EdgeInsets.all(20),
              children: const [
                Icon(Icons.cloud_off, size: 70),
                SizedBox(height: 12),
                Text('Firebase connection / permission setup बाकी आहे.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text('Customer request save करण्यासाठी Firestore rules आणि login/auth पुढील टप्प्यात जोडू.',
                    textAlign: TextAlign.center),
              ],
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('सध्या नवीन Vehicle Rent Requests नाहीत.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 20)),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final d = doc.data();
              final status = (d['status'] ?? 'pending').toString();
              final vehicle = (d['vehicleType'] ?? 'Vehicle').toString();
              final service = (d['service'] ?? 'Only Vehicle').toString();
              final total = (d['total'] ?? 0).toString();
              final days = (d['days'] ?? 1).toString();
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('$vehicle • $service',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text('₹$total • $days दिवस • Status: ${status.toUpperCase()}'),
                      const SizedBox(height: 4),
                      Text('Pickup: ${(d['pickupLocation'] ?? '—').toString()}'),
                      if (status == 'pending') ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: () => _acceptRequest(context, doc.id, d),
                                icon: const Icon(Icons.check),
                                label: const Text('Accept'),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _updateStatus(doc.id, 'rejected'),
                                icon: const Icon(Icons.close),
                                label: const Text('Reject'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _updateStatus(String id, String status) async {
    await FirebaseFirestore.instance
        .collection('vehicle_rent_requests')
        .doc(id)
        .update({
      'status': status,
      'ownerUpdatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _acceptRequest(
      BuildContext context, String id, Map<String, dynamic> data) async {
    final nameController = TextEditingController(
      text: (data['ownerName'] ?? 'Vehicle Owner').toString(),
    );
    final phoneController = TextEditingController(
      text: (data['ownerPhone'] ?? '').toString(),
    );
    final priceController = TextEditingController(
      text: (data['total'] ?? 0).toString(),
    );

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Booking Confirm करा'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Vehicle Owner Name',
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                maxLength: 10,
                decoration: const InputDecoration(
                  labelText: 'Owner Mobile Number',
                  prefixIcon: Icon(Icons.phone),
                  counterText: '',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Final Price (₹)',
                  prefixIcon: Icon(Icons.currency_rupee),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final phone = phoneController.text.trim();
              final price = int.tryParse(priceController.text.trim()) ?? 0;
              if (!RegExp(r'^[6-9]\d{9}$').hasMatch(phone)) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(
                    content: Text('कृपया 10 अंकी वैध Mobile Number टाका.'),
                  ),
                );
                return;
              }
              if (price <= 0) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(
                    content: Text('कृपया Final Price योग्य रक्कम टाका.'),
                  ),
                );
                return;
              }
              Navigator.pop(dialogContext, true);
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );

    if (result != true) return;

    final ownerName = nameController.text.trim().isEmpty
        ? 'Vehicle Owner'
        : nameController.text.trim();
    final ownerPhone = phoneController.text.trim();
    final finalPrice = int.tryParse(priceController.text.trim()) ??
        int.tryParse((data['total'] ?? 0).toString()) ??
        0;

    await FirebaseFirestore.instance
        .collection('vehicle_rent_requests')
        .doc(id)
        .update({
      'status': 'accepted',
      'ownerName': ownerName,
      'ownerPhone': ownerPhone,
      'finalPrice': finalPrice,
      'ownerUpdatedAt': FieldValue.serverTimestamp(),
    });
  }
}

class VehicleRentBookingDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> data;

  const VehicleRentBookingDetailsScreen({super.key, required this.data});

  String _dateText(dynamic value) {
    if (value is Timestamp) {
      final d = value.toDate();
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    }
    return value?.toString() ?? '—';
  }

  @override
  Widget build(BuildContext context) {
    final vehicle = (data['vehicleType'] ?? 'Vehicle').toString();
    final service = (data['service'] ?? 'Only Vehicle').toString();
    final pickup = (data['pickupLocation'] ?? 'Current location (demo)').toString();
    final days = (data['days'] ?? 1).toString();
    final estimated = (data['total'] ?? 0).toString();
    final finalPrice = data['finalPrice'];
    final ownerName = (data['ownerName'] ?? 'Vehicle Owner').toString();
    final ownerPhone = (data['ownerPhone'] ?? '').toString();
    final requestId = (data['requestId'] ?? '—').toString();

    return Scaffold(
      appBar: AppBar(title: const Text('Booking Details')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 34,
                    child: Icon(Icons.check, size: 38),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Booking Confirmed ✅',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '$vehicle • $service',
                    style: const TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '📋 Booking Information',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  _detailRow(Icons.directions_car, 'Vehicle', '$vehicle • $service'),
                  _detailRow(Icons.location_on, 'Pickup Location', pickup),
                  _detailRow(Icons.calendar_month, 'Start Date', _dateText(data['startDate'])),
                  _detailRow(Icons.event, 'Rental Duration', '$days दिवस'),
                  _detailRow(Icons.currency_rupee, 'Estimated Price', '₹$estimated'),
                  _detailRow(
                    Icons.price_check,
                    'Final Price',
                    finalPrice == null ? '₹$estimated' : '₹${finalPrice.toString()}',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '👤 Vehicle Owner',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    ownerName,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    ownerPhone.isEmpty
                        ? 'Mobile number उपलब्ध नाही'
                        : '📞 $ownerPhone',
                    style: const TextStyle(fontSize: 17),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => _showCallInfo(context, ownerPhone),
                          icon: const Icon(Icons.call),
                          label: const Text('Call Owner'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _showPickupInfo(context, pickup),
                          icon: const Icon(Icons.map),
                          label: const Text('Pickup'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: const Icon(Icons.confirmation_number),
              title: const Text('Booking ID'),
              subtitle: Text(requestId),
              trailing: IconButton(
                tooltip: 'Copy',
                icon: const Icon(Icons.copy),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: requestId));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Booking ID copied')),
                  );
                },
              ),
            ),
          ),
          if (data['status']?.toString().toLowerCase() == 'accepted') ...[
            const SizedBox(height: 14),
            _VehicleRentPaymentStatusCard(
              requestId: requestId,
              bookingData: data,
            ),
          ],
          const SizedBox(height: 10),
          const Text(
            'टीप: Final price आणि pickup details Vehicle Owner/Admin availability नुसार बदलू शकतात.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _detailRow(IconData icon, String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 23),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(fontSize: 17)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showCallInfo(BuildContext context, String phone) async {
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Owner mobile number उपलब्ध नाही.')),
      );
      return;
    }
    final uri = Uri(scheme: 'tel', path: phone);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        throw Exception('dialer unavailable');
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Call करता आला नाही: $phone')),
        );
      }
    }
  }

  Future<void> _showPickupInfo(BuildContext context, String pickup) async {
    if (pickup.trim().isEmpty || pickup.trim() == '—') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pickup location उपलब्ध नाही.')),
      );
      return;
    }

    final query = Uri.encodeComponent(pickup.trim());
    final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=$query');

    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google Maps/Browser उघडता आले नाही.')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google Maps/Browser उघडता आले नाही.')),
        );
      }
    }
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});
  @override State<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends State<DriverDashboard> {
  bool online = false;

  Future<void> _respondToRequest(
      BuildContext context, String id, bool accept) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final ref = FirebaseFirestore.instance.collection('driver_requests').doc(id);
    final snap = await ref.get();
    if (!snap.exists) return;
    final d = snap.data() ?? {};
    if ((d['status'] ?? 'pending') != 'pending') return;

    final driverSnap = await FirebaseFirestore.instance
        .collection('drivers').doc(user.uid).get();
    final driver = driverSnap.data() ?? {};
    final name = (driver['name'] ?? driver['fullName'] ?? 'Driver').toString();
    final phone = (driver['phone'] ?? user.phoneNumber ?? '').toString();

    await ref.update({
      'status': accept ? 'accepted' : 'rejected',
      'driverId': accept ? user.uid : null,
      'driverName': accept ? name : null,
      'driverPhone': accept ? phone : null,
      'acceptedAt': accept ? FieldValue.serverTimestamp() : null,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(accept
          ? '✅ Booking accepted. Customer ला Driver details मिळतील.'
          : 'Request rejected.')),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Dashboard')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: SwitchListTile(
                value: online,
                onChanged: (v) async {
                  final user = FirebaseAuth.instance.currentUser;
                  if (user == null) return;
                  final snap = await FirebaseFirestore.instance
                      .collection('drivers').doc(user.uid).get();
                  final d = snap.data() ?? {};
                  final approved = d['adminApproved'] == true ||
                      d['adminStatus'] == 'approved';
                  final blocked = d['adminBlocked'] == true ||
                      d['adminStatus'] == 'blocked';
                  if (!approved || blocked) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(blocked
                            ? 'Admin ने Driver block केला आहे.'
                            : 'Online होण्यासाठी Admin approval आवश्यक आहे.'),
                      ),
                    );
                    return;
                  }
                  try {
                    await FirebaseFirestore.instance
                        .collection('drivers').doc(user.uid).set({
                      'isOnline': v,
                      'onlineAt': v ? FieldValue.serverTimestamp() : null,
                      'lastSeenAt': FieldValue.serverTimestamp(),
                      'updatedAt': FieldValue.serverTimestamp(),
                    }, SetOptions(merge: true));
                    if (!mounted) return;
                    setState(() => online = v);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(v
                            ? '🟢 Driver Online झाला. Booking requests मिळतील.'
                            : '🔴 Driver Offline झाला.'),
                      ),
                    );
                  } on FirebaseException catch (e) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                            'Status save झाला नाही: ${e.message ?? e.code}'),
                      ),
                    );
                  }
                },
                title: Text(online ? '🟢 ONLINE' : '🔴 OFFLINE',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(online
                    ? 'Booking requests receive होतील'
                    : 'Online होण्यासाठी Admin approval आवश्यक'),
              ),
            ),
            const Card(
              child: ListTile(
                leading: CircleAvatar(child: Icon(Icons.person)),
                title: Text('Raj Patil'),
                subtitle: Text('⭐ 4.8 • KYC Verified • Car'),
              ),
            ),
            const SizedBox(height: 12),
            if (online) ...[
              const Text('🔔 नवीन Booking Requests',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: FirebaseFirestore.instance
                    .collection('driver_requests')
                    .where('status', isEqualTo: 'pending')
                    .orderBy('createdAt', descending: true)
                    .limit(10)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Text(
                            'Requests load झाल्या नाहीत: ${snapshot.error}'),
                      ),
                    );
                  }
                  final docs = snapshot.data?.docs ?? [];
                  if (docs.isEmpty) {
                    return const Card(
                      child: ListTile(
                        leading: Icon(Icons.hourglass_empty),
                        title: Text('सध्या नवीन request नाही.'),
                        subtitle: Text('Customer request केल्यावर येथे दिसेल.'),
                      ),
                    );
                  }
                  return Column(
                    children: docs.map((doc) {
                      final d = doc.data();
                      final vehicle = (d['vehicle'] ?? 'Vehicle').toString();
                      final duration = (d['duration'] ?? '—').toString();
                      final fare = (d['fare'] ?? 0).toString();
                      final pickup =
                          (d['pickupLocation'] ?? '—').toString();
                      final bookingTime = d['bookingDateTime'] ?? d['createdAt'];
                      String bookingTimeText = '—';
                      if (bookingTime is Timestamp) {
                        final dt = bookingTime.toDate().toLocal();
                        final date = '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
                        final hour = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
                        final minute = dt.minute.toString().padLeft(2, '0');
                        bookingTimeText = '$date • $hour:$minute ${dt.hour >= 12 ? 'PM' : 'AM'}';
                      }
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('$vehicle • $duration',
                                  style: const TextStyle(
                                      fontSize: 19,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 6),
                              Text('🗓️ Booking: $bookingTimeText', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 4),
                              Text('💰 अंदाजे ₹$fare'),
                              Text('📍 $pickup'),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Expanded(
                                    child: FilledButton.icon(
                                      onPressed: () => _respondToRequest(
                                          context, doc.id, true),
                                      icon: const Icon(Icons.check),
                                      label: const Text('Accept'),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      onPressed: () => _respondToRequest(
                                          context, doc.id, false),
                                      icon: const Icon(Icons.close),
                                      label: const Text('Reject'),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
              const SizedBox(height: 12),
            ],
            const Text('आजची माहिती',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const Card(
              child: ListTile(
                title: Text('आजच्या Bookings'),
                trailing: Text('5'),
              ),
            ),
            const Card(
              child: ListTile(
                title: Text('आजची कमाई'),
                trailing: Text('₹1,850'),
              ),
            ),
            const Card(
              child: ListTile(
                title: Text('My Earnings'),
                trailing: Text('₹32,500'),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => go(context, const DriverRegistrationScreen()),
              icon: const Icon(Icons.person_add),
              label: const Text('Driver Registration'),
            ),
          ],
        ),
      );
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class DriverRegistrationScreen extends StatefulWidget {
  const DriverRegistrationScreen({super.key});

  @override
  State<DriverRegistrationScreen> createState() => _DriverRegistrationScreenState();
}

class _DriverRegistrationScreenState extends State<DriverRegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  final _licenceController = TextEditingController();
  final _idProofController = TextEditingController();
  final _vehicleController = TextEditingController();
  final _rcController = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    _licenceController.dispose();
    _idProofController.dispose();
    _vehicleController.dispose();
    _rcController.dispose();
    super.dispose();
  }

  Future<void> _submitRegistration() async {
    if (!_formKey.currentState!.validate()) return;

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('कृपया आधी Login करा.')),
      );
      return;
    }

    setState(() => _saving = true);

    try {
      final driverRef = FirebaseFirestore.instance.collection('drivers').doc(user.uid);
      await driverRef.set({
        'uid': user.uid,
        'name': _nameController.text.trim(),
        'fullName': _nameController.text.trim(),
        'phone': _mobileController.text.trim(),
        'drivingLicence': _licenceController.text.trim(),
        'idProof': _idProofController.text.trim(),
        'vehicleNumber': _vehicleController.text.trim(),
        'rcDocument': _rcController.text.trim(),
        'kycStatus': 'pending',
        'adminApproved': false,
        'adminBlocked': false,
        'adminStatus': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => const AlertDialog(
          title: Text('Registration Received ✅'),
          content: Text(
              'तुमची माहिती Admin verification साठी पाठवली आहे.'),
        ),
      );
    } on FirebaseException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Registration save झाला नाही: ${e.message ?? e.code}')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Registration save झाला नाही: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _field(String label, TextEditingController controller,
      {TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: (value) {
          if (value == null || value.trim().isEmpty) return '$label भरा';
          return null;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Registration')),
        body: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text('Driver म्हणून नोंदणी करा',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 18),
              _field('पूर्ण नाव', _nameController),
              _field('Mobile Number', _mobileController,
                  keyboardType: TextInputType.phone),
              _field('Driving Licence', _licenceController),
              _field('ID Proof', _idProofController),
              _field('Vehicle Number', _vehicleController),
              _field('RC Document', _rcController),
              FilledButton(
                onPressed: _saving ? null : _submitRegistration,
                child: Text(_saving ? 'Saving...' : 'Registration Submit करा'),
              ),
            ],
          ),
        ),
      );
}

