# Driver On Call Admin Panel

First MVP: Firebase Email/Password login + dashboard counts + recent vehicle-rent bookings.

Important: this is the first UI build. Before production use, add a proper admin role/custom-claims check and restrictive Firestore rules. Do not expose Firebase service-account credentials in this folder.

Hosting: GitHub Pages can serve `admin/index.html` after Pages is enabled.
