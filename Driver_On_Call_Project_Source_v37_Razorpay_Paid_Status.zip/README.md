Driver On Call v36 - Razorpay Test Payment

This version adds Razorpay Test Checkout to accepted Vehicle Rent bookings.

Flow:
1. Customer taps PAY NOW.
2. App creates payment_requests/{id} in Firestore.
3. A secure server-side worker creates the Razorpay Order.
4. App opens Razorpay Test Checkout.
5. App writes payment response to Firestore.
6. Server-side worker verifies the Razorpay signature and marks the booking paid.

Required GitHub repository secrets:
- FIREBASE_SERVICE_ACCOUNT_JSON (already present)
- RAZORPAY_KEY_ID
- RAZORPAY_KEY_SECRET

Never put RAZORPAY_KEY_SECRET in the Android app or commit it to Git.
