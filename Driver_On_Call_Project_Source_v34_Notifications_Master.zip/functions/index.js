const { onDocumentUpdated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();

exports.notifyCustomerBookingStatus = onDocumentUpdated(
  "vehicle_rent_requests/{requestId}",
  async (event) => {
    const before = event.data?.before?.data();
    const after = event.data?.after?.data();
    if (!before || !after) return;

    const oldStatus = String(before.status || "pending");
    const newStatus = String(after.status || "pending");
    if (oldStatus === newStatus) return;
    if (newStatus !== "accepted" && newStatus !== "rejected") return;

    const customerId = String(after.customerId || "");
    if (!customerId) return;

    const tokenSnap = await admin.firestore()
      .collection("user_notification_tokens")
      .doc(customerId)
      .get();
    if (!tokenSnap.exists) return;

    const token = String(tokenSnap.data().token || "");
    if (!token) return;

    const vehicle = String(after.vehicleType || "Vehicle");
    const title = newStatus === "accepted"
      ? "Booking Confirmed 🚗"
      : "Booking Rejected 🚗";
    const body = newStatus === "accepted"
      ? `${vehicle} booking accepted. Owner confirmation is ready.`
      : `${vehicle} booking was rejected. Please check the app.`;

    try {
      await admin.messaging().send({
        token,
        notification: { title, body },
        data: {
          type: "vehicle_rent_status",
          requestId: event.params.requestId,
          status: newStatus,
        },
        android: {
          notification: {
            channelId: "booking_updates",
            priority: "high",
          },
        },
      });
    } catch (error) {
      const code = String(error?.code || "");
      if (code.includes("registration-token-not-registered") ||
          code.includes("invalid-registration-token")) {
        await tokenSnap.ref.delete();
      } else {
        console.error("Booking notification failed", error);
      }
    }
  }
);
