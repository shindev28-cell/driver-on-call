
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

final FlutterLocalNotificationsPlugin _localNotifications =
    FlutterLocalNotificationsPlugin();

const AndroidNotificationChannel _bookingChannel = AndroidNotificationChannel(
  'booking_updates',
  'Booking Updates',
  description: 'Vehicle Rent booking status notifications',
  importance: Importance.high,
  playSound: true,
);

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Notification payloads are displayed automatically by FCM when the app is
  // in the background. Data-only messages can be handled here in future.
}

Future<void> _initLocalNotifications() async {
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  const settings = InitializationSettings(android: android);
  await _localNotifications.initialize(settings);
  final androidPlugin = _localNotifications
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  await androidPlugin?.createNotificationChannel(_bookingChannel);
  await androidPlugin?.requestNotificationsPermission();
}

Future<void> _showForegroundNotification(RemoteMessage message) async {
  final notification = message.notification;
  if (notification == null) return;
  await _localNotifications.show(
    DateTime.now().millisecondsSinceEpoch ~/ 1000,
    notification.title ?? 'Driver On Call',
    notification.body ?? 'Booking status updated',
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'booking_updates',
        'Booking Updates',
        channelDescription: 'Vehicle Rent booking status notifications',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
      ),
    ),
  );
}

Future<void> _setupFirebaseMessaging() async {
  try {
    await _initLocalNotifications();
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    final token = await messaging.getToken();
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (token != null && uid != null) {
      await FirebaseFirestore.instance
          .collection('user_notification_tokens')
          .doc(uid)
          .set({
        'token': token,
        'updatedAt': FieldValue.serverTimestamp(),
        'platform': 'android',
      }, SetOptions(merge: true));
    }

    messaging.onTokenRefresh.listen((newToken) async {
      final currentUid = FirebaseAuth.instance.currentUser?.uid;
      if (currentUid == null) return;
      try {
        await FirebaseFirestore.instance
            .collection('user_notification_tokens')
            .doc(currentUid)
            .set({
          'token': newToken,
          'updatedAt': FieldValue.serverTimestamp(),
          'platform': 'android',
        }, SetOptions(merge: true));
      } catch (_) {}
    });

    FirebaseMessaging.onMessage.listen((message) async {
      debugPrint('FCM foreground message: ${message.notification?.title}');
      await _showForegroundNotification(message);
    });
  } catch (_) {
    // Notifications are optional during testing; never block app startup.
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: 'AIzaSyCKKgG38JlJDjZQbPQC2jdaxIwJ1gZX5V8',
        appId: '1:273781697153:android:1981de83c225a20b10fb80',
        messagingSenderId: '273781697153',
        projectId: 'driver-on-call-d2a72',
        storageBucket: 'driver-on-call-d2a72.firebasestorage.app',
      ),
    );
    FirebaseMessaging.onBackgroundMessage(
      _firebaseMessagingBackgroundHandler,
    );
    if (FirebaseAuth.instance.currentUser != null) {
      await _setupFirebaseMessaging();
    }
  } catch (_) {
    // The app can still open in demo mode if Firebase is unavailable.
  }
  runApp(const DriverOnCall());
}


class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data != null) return const HomeScreen();
        return const PhoneLoginScreen();
      },
    );
  }
}

/// No-billing testing login.
/// Firebase Phone Auth sends real SMS only on a paid Blaze plan, so this
/// version uses a local demo OTP and Firebase Anonymous Auth. It is intended
/// for testing the app flow, not as production identity verification.
class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});

  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final phoneController = TextEditingController();
  final otpController = TextEditingController();
  bool codeSent = false;
  bool loading = false;
  String message = '';

  // Demo-only OTP. Never use a fixed OTP for production authentication.
  static const demoOtp = '123456';

  @override
  void dispose() {
    phoneController.dispose();
    otpController.dispose();
    super.dispose();
  }

  void _sendOtp() {
    final phone = phoneController.text.trim();
    if (!RegExp(r'^\d{10}$').hasMatch(phone)) {
      setState(() => message = 'कृपया 10 अंकी Mobile Number टाका.');
      return;
    }
    setState(() {
      codeSent = true;
      message = 'Testing OTP: 123456  (SMS पाठवला जाणार नाही)';
    });
  }

  Future<void> _verifyOtp() async {
    final otp = otpController.text.trim();
    if (otp != demoOtp) {
      setState(() => message = 'OTP चुकीचा आहे. Testing OTP: 123456');
      return;
    }

    setState(() {
      loading = true;
      message = '';
    });

    try {
      // Anonymous Auth is free and does not require Firebase Blaze billing.
      await FirebaseAuth.instance.signInAnonymously();
      await _setupFirebaseMessaging();
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        message = e.message ??
            'Anonymous Login बंद आहे. Firebase Authentication मध्ये Anonymous provider Enable करा.';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        message = 'Login झाला नाही. पुन्हा प्रयत्न करा.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver On Call Login')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 35),
          const Icon(Icons.phone_android, size: 80),
          const SizedBox(height: 18),
          const Text(
            'Mobile Number ने Login करा',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            'No-billing Testing Login',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17),
          ),
          const SizedBox(height: 28),
          if (!codeSent) ...[
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: const InputDecoration(
                prefixText: '+91 ',
                labelText: 'Mobile Number',
                hintText: '9876543210',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: loading ? null : _sendOtp,
              icon: const Icon(Icons.sms),
              label: const Text('OTP पाठवा'),
            ),
          ] else ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  'Testing OTP: $demoOtp\nहा OTP SMS ने येणार नाही.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 17),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: otpController,
              keyboardType: TextInputType.number,
              maxLength: 6,
              decoration: const InputDecoration(
                labelText: 'OTP',
                hintText: '123456',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: loading ? null : _verifyOtp,
              icon: const Icon(Icons.verified),
              label: Text(loading ? 'Login होत आहे...' : 'OTP Verify करा'),
            ),
            TextButton(
              onPressed: loading
                  ? null
                  : () => setState(() {
                        codeSent = false;
                        message = '';
                        otpController.clear();
                      }),
              child: const Text('Mobile Number बदला'),
            ),
          ],
          if (message.isNotEmpty) ...[
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(message, textAlign: TextAlign.center),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class DriverOnCall extends StatelessWidget {
  const DriverOnCall({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Driver On Call',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5866A3)),
        scaffoldBackgroundColor: const Color(0xFFF9F7FC),
      ),
      home: const AuthGate(),
    );
  }
}

void go(BuildContext c, Widget page) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => page));

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String vehicle = 'Car';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver On Call',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Vehicle Owner',
            icon: const Icon(Icons.car_rental),
            onPressed: () => go(context, const VehicleOwnerDashboard()),
          ),
          IconButton(
            tooltip: 'Driver Mode',
            icon: const Icon(Icons.drive_eta),
            onPressed: () => go(context, const DriverDashboard()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(28, 28, 28, 24),
        children: [
          const Text('नमस्कार! 👋',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('गरज असेल तेव्हा Driver तुमच्या जवळ.',
              style: TextStyle(fontSize: 18)),
          const SizedBox(height: 30),
          _mainButton(context, Icons.flash_on, 'आत्ता Driver हवा', () {
            go(context, const NowBookingScreen());
          }),
          _mainButton(context, Icons.calendar_month, 'Driver Schedule करा', () {
            go(context, const ScheduleBookingScreen());
          }),
          _mainButton(context, Icons.directions_car, '🚗 Vehicle Rent', () {
            go(context, const VehicleRentScreen());
          }),
          _mainButton(context, Icons.history, '📋 माझ्या Bookings', () {
            go(context, const BookingHistoryScreen());
          }),
          _mainButton(context, Icons.car_rental, '🏢 Vehicle Owner', () {
            go(context, const VehicleOwnerDashboard());
          }),
          const SizedBox(height: 14),
          Card(
            elevation: 1,
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              leading: const Icon(Icons.location_on, size: 30),
              title: const Text('Pickup Location',
                  style: TextStyle(fontSize: 19)),
              subtitle: const Text('Current location (demo)',
                  style: TextStyle(fontSize: 16)),
              trailing: IconButton(
                icon: const Icon(Icons.edit_location_alt),
                onPressed: () => _locationDialog(context),
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Text('वाहनाचा प्रकार',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: ['Car', 'SUV', 'Other'].map((v) {
              return ChoiceChip(
                label: Text(v == 'Car' ? '🚗 Car' : v == 'SUV' ? '🚙 SUV' : '🛻 Other'),
                selected: vehicle == v,
                onSelected: (_) => setState(() => vehicle = v),
              );
            }).toList(),
          ),
          const SizedBox(height: 22),
          _menuCard(context, Icons.car_rental, 'Vehicle Rent Status',
              () => go(context, const VehicleRentStatusScreen())),
          _menuCard(context, Icons.support_agent, 'Help & Support',
              () => go(context, const SupportScreen())),
        ],
      ),
    );
  }

  Widget _mainButton(BuildContext c, IconData icon, String text, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(64),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        onPressed: tap,
        icon: Icon(icon, size: 30),
        label: Text(text, style: const TextStyle(fontSize: 21)),
      ),
    );
  }

  Widget _menuCard(
      BuildContext c, IconData icon, String title, VoidCallback tap) {
    return Card(
      child: ListTile(
        leading: Icon(icon, size: 30),
        title: Text(title, style: const TextStyle(fontSize: 19)),
        trailing: const Icon(Icons.chevron_right),
        onTap: tap,
      ),
    );
  }

  void _locationDialog(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('Pickup Location'),
        content: const Text(
            'Vehicle Rent मध्ये Pickup Location म्हणून तुमचे ठिकाण टाका. Booking Details मधील Pickup बटण ते ठिकाण Google Maps मध्ये उघडेल.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('OK'))
        ],
      ),
    );
  }
}

class PickupLocationEditScreen extends StatefulWidget {
  final String initialValue;

  const PickupLocationEditScreen({super.key, required this.initialValue});

  @override
  State<PickupLocationEditScreen> createState() => _PickupLocationEditScreenState();
}

class _PickupLocationEditScreenState extends State<PickupLocationEditScreen> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _save() {
    final value = _controller.text.trim();
    if (value.isEmpty) return;
    Navigator.of(context).pop(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pickup Location'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Pickup ठिकाण',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _controller,
              autofocus: true,
              maxLines: 2,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _save(),
              decoration: const InputDecoration(
                hintText: 'उदा. Barshi ST Stand, Solapur',
                labelText: 'Pickup Location',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.check),
              label: const Text('सेव्ह'),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
            ),
          ],
        ),
      ),
    );
  }
}

class VehicleRentScreen extends StatefulWidget {
  const VehicleRentScreen({super.key});
  @override
  State<VehicleRentScreen> createState() => _VehicleRentScreenState();
}

class _VehicleRentScreenState extends State<VehicleRentScreen> {
  String service = 'Only Vehicle';
  String vehicleType = 'Car';
  int days = 1;
  DateTime startDate = DateTime.now();
  String pickupLocation = 'Current location (demo)';

  int get dailyRate {
    if (vehicleType == 'SUV') return service == 'Vehicle + Driver' ? 3500 : 2800;
    if (vehicleType == 'Tempo Traveller') {
      return service == 'Vehicle + Driver' ? 5000 : 4200;
    }
    return service == 'Vehicle + Driver' ? 2500 : 1800;
  }

  int get total => dailyRate * days;

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: startDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => startDate = picked);
  }

  Future<void> _editPickupLocation() async {
    final result = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => PickupLocationEditScreen(
          initialValue:
              pickupLocation == 'Current location (demo)' ? '' : pickupLocation,
        ),
      ),
    );
    if (result != null && result.isNotEmpty && mounted) {
      setState(() => pickupLocation = result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateText = '${startDate.day.toString().padLeft(2, '0')}/'
        '${startDate.month.toString().padLeft(2, '0')}/${startDate.year}';

    return Scaffold(
      appBar: AppBar(title: const Text('🚗 Vehicle Rent')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          const Text('तुम्हाला वाहन कसे हवे?',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'Only Vehicle', label: Text('🚗 Only Vehicle')),
              ButtonSegment(value: 'Vehicle + Driver', label: Text('👨‍✈️ + Driver')),
            ],
            selected: {service},
            onSelectionChanged: (v) => setState(() => service = v.first),
          ),
          const SizedBox(height: 24),
          const Text('वाहन निवडा',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...['Car', 'SUV', 'Tempo Traveller'].map((v) => Card(
                child: RadioListTile<String>(
                  value: v,
                  groupValue: vehicleType,
                  onChanged: (value) => setState(() => vehicleType = value!),
                  title: Text(v == 'Car'
                      ? '🚗 Car'
                      : v == 'SUV'
                          ? '🚙 SUV'
                          : '🚐 Tempo Traveller'),
                  subtitle: Text('₹${v == 'Car' ? 1800 : v == 'SUV' ? 2800 : 4200} / दिवसापासून'),
                ),
              )),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.calendar_month, size: 30),
              title: const Text('Start Date'),
              subtitle: Text(dateText),
              trailing: OutlinedButton(
                onPressed: _pickDate,
                child: const Text('बदला'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.location_on, size: 30),
              title: const Text('Pickup Location', style: TextStyle(fontSize: 18)),
              subtitle: Text(pickupLocation, style: const TextStyle(fontSize: 16)),
              trailing: OutlinedButton.icon(
                onPressed: _editPickupLocation,
                icon: const Icon(Icons.edit_location_alt),
                label: const Text('बदला'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Text('किती दिवस?', style: TextStyle(fontSize: 18)),
                  ),
                  IconButton(
                    onPressed: days > 1 ? () => setState(() => days--) : null,
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text('$days',
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  IconButton(
                    onPressed: days < 30 ? () => setState(() => days++) : null,
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            elevation: 1,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$vehicleType • $service',
                      style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 8),
                  Text('₹$dailyRate × $days दिवस',
                      style: const TextStyle(fontSize: 16)),
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('अंदाजे एकूण',
                          style: TextStyle(
                              fontSize: 19, fontWeight: FontWeight.bold)),
                      Text('₹$total',
                          style: const TextStyle(
                              fontSize: 25, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text('Final price availability आणि admin rates नुसार बदलू शकतो.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => _submitRentRequest(context, dateText),
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Vehicle Rent Request करा',
                style: TextStyle(fontSize: 18)),
          ),
        ],
      ),
    );
  }
  Future<void> _submitRentRequest(BuildContext context, String dateText) async {
    final data = {
      'service': service,
      'vehicleType': vehicleType,
      'startDate': Timestamp.fromDate(startDate),
      'days': days,
      'dailyRate': dailyRate,
      'total': total,
      'pickupLocation': pickupLocation,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'customerName': 'Guest Customer',
      'customerId': FirebaseAuth.instance.currentUser?.uid ?? '',
    };

    String message = 'Request तयार झाली आहे. Vehicle Owner कडून confirmation येईल.';
    String? requestId;
    try {
      final ref = await FirebaseFirestore.instance
          .collection('vehicle_rent_requests')
          .add(data);
      requestId = ref.id;
    } catch (_) {
      message = 'Request demo mode मध्ये तयार झाली. Firebase permission/auth सेट केल्यावर ती Owner ला live दिसेल.';
    }

    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Vehicle Rent Request 🚗'),
        content: Text(
          '$vehicleType • $service\n$dateText पासून $days दिवस\nअंदाजे ₹$total\n\n$message'
          '${requestId == null ? '' : '\n\nRequest ID: $requestId'}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('ठीक आहे'),
          ),
          if (requestId != null)
            FilledButton(
              onPressed: () {
                Navigator.pop(context);
                go(context, const VehicleRentStatusScreen());
              },
              child: const Text('Status पाहा'),
            ),
        ],
      ),
    );
  }
}

class VehicleRentStatusScreen extends StatelessWidget {
  const VehicleRentStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Vehicle Rent Status')),
      body: uid.isEmpty
          ? const Center(child: Text('Login session सापडली नाही.'))
          : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('vehicle_rent_requests')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Booking status पाहता आला नाही. Firebase permission तपासा.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data?.docs
                        .where((doc) => (doc.data()['customerId'] ?? '') == uid)
                        .toList() ??
                    [];

                if (docs.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'तुमची Vehicle Rent booking अजून उपलब्ध नाही.\n\nनवीन request केल्यावर तिचा status इथे दिसेल.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 19),
                      ),
                    ),
                  );
                }

                docs.sort((a, b) {
                  final at = a.data()['createdAt'];
                  final bt = b.data()['createdAt'];
                  if (at is Timestamp && bt is Timestamp) {
                    return bt.compareTo(at);
                  }
                  if (at is Timestamp) return -1;
                  if (bt is Timestamp) return 1;
                  return b.id.compareTo(a.id);
                });

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final d = <String, dynamic>{
                      ...doc.data(),
                      'requestId': doc.id,
                    };
                    final status = (d['status'] ?? 'pending').toString();
                    final vehicle = (d['vehicleType'] ?? 'Vehicle').toString();
                    final service = (d['service'] ?? 'Only Vehicle').toString();
                    final total = (d['total'] ?? 0).toString();
                    final finalPrice = d['finalPrice'];
                    final days = (d['days'] ?? 1).toString();
                    final accepted = status == 'accepted';
                    final rejected = status == 'rejected';

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: Card(
                        elevation: 2,
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            children: [
                              Icon(
                                accepted
                                    ? Icons.check_circle
                                    : rejected
                                        ? Icons.cancel
                                        : Icons.hourglass_top,
                                size: 62,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                accepted
                                    ? 'Vehicle Confirmed ✅'
                                    : rejected
                                        ? 'Request Rejected'
                                        : 'Confirmation Pending ⏳',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 23,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(
                                '$vehicle • $service',
                                style: const TextStyle(fontSize: 20),
                              ),
                              const SizedBox(height: 7),
                              Text('₹$total • $days दिवस'),
                              if (accepted && finalPrice != null) ...[
                                const SizedBox(height: 5),
                                Text(
                                  'Final Price: ₹$finalPrice',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                              const SizedBox(height: 12),
                              Text(
                                accepted
                                    ? 'Vehicle Owner ने तुमची booking स्वीकारली आहे.'
                                    : rejected
                                        ? 'Vehicle Owner ने ही request नाकारली आहे.'
                                        : 'Vehicle Owner कडून confirmation ची वाट पाहत आहोत.',
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 16),
                              ),
                              if (accepted) ...[
                                const SizedBox(height: 14),
                                SizedBox(
                                  width: double.infinity,
                                  child: FilledButton.icon(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              VehicleRentBookingDetailsScreen(
                                            data: d,
                                          ),
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.verified),
                                    label: const Text('Booking Details उघडा'),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class NowBookingScreen extends StatefulWidget {
  const NowBookingScreen({super.key});
  @override State<NowBookingScreen> createState() => _NowBookingScreenState();
}

class _NowBookingScreenState extends State<NowBookingScreen> {
  String duration = '4 तास';
  String purpose = 'माझी गाडी Driver ने चालवावी';
  String vehicle = 'Car';

  @override
  Widget build(BuildContext context) {
    final fare = vehicle == 'SUV' ? 1200 : vehicle == 'Other' ? 1050 : 900;
    return Scaffold(
      appBar: AppBar(title: const Text('आता Driver हवा')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _section('📍 Pickup Location',
              const Text('Current location (demo)')),
          _section('🚗 वाहनाचा प्रकार',
              DropdownButtonFormField<String>(
                value: vehicle,
                items: ['Car', 'SUV', 'Other']
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() => vehicle = v!),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              )),
          _section('Driver कशासाठी हवा?',
              DropdownButtonFormField<String>(
                value: purpose,
                items: [
                  'माझी गाडी Driver ने चालवावी',
                  'Driver सोबत वाहन हवे'
                ]
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() => purpose = v!),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              )),
          _section('⏱️ किती वेळासाठी?',
              Wrap(
                spacing: 8,
                children: ['2 तास', '4 तास', '8 तास', 'पूर्ण दिवस']
                    .map((v) => ChoiceChip(
                          label: Text(v),
                          selected: duration == v,
                          onSelected: (_) => setState(() => duration = v),
                        ))
                    .toList(),
              )),
          Card(
            child: ListTile(
              title: const Text('अंदाजे भाडे'),
              trailing: Text('₹$fare',
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold)),
              subtitle: const Text('Admin fare settings नुसार estimate'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.flash_on),
            label: const Text('Driver शोधा',
                style: TextStyle(fontSize: 19)),
            onPressed: () => go(context, SearchingDriverScreen(
              vehicle: vehicle, duration: duration, fare: fare,
            )),
          ),
        ],
      ),
    );
  }

  Widget _section(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            child,
          ],
        ),
      );
}

class SearchingDriverScreen extends StatelessWidget {
  final String vehicle, duration;
  final int fare;
  const SearchingDriverScreen(
      {super.key, required this.vehicle, required this.duration, required this.fare});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver शोधत आहे')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 25),
            const Text('जवळचा Driver शोधत आहे...',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text('$vehicle • $duration • अंदाजे ₹$fare'),
            const SizedBox(height: 30),
            FilledButton(
              onPressed: () => go(context, const AssignedScreen()),
              child: const Text('Demo: Driver मिळाला'),
            ),
          ]),
        ),
      ),
    );
  }
}

class AssignedScreen extends StatelessWidget {
  const AssignedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Confirmed ✅')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const CircleAvatar(radius: 52, child: Icon(Icons.person, size: 56)),
            const SizedBox(height: 12),
            const Center(
                child: Text('Raj Patil',
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
            const Center(child: Text('⭐ 4.8  •  ✓ Verified Driver')),
            const SizedBox(height: 18),
            Card(
              child: Column(children: [
                const ListTile(
                    leading: Icon(Icons.directions_car),
                    title: Text('Car'),
                    subtitle: Text('MH-XX-1234')),
                ListTile(
                    leading: const Icon(Icons.location_on),
                    title: const Text('ETA'),
                    subtitle: const Text('8 minutes • Live location (demo)')),
                ListTile(
                    leading: const Icon(Icons.phone),
                    title: const Text('Call Driver'),
                    onTap: () {}),
              ]),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => go(context, const TripScreen()),
              child: const Text('START / VIEW TRIP'),
            ),
            OutlinedButton(
              onPressed: () => _cancel(context),
              child: const Text('CANCEL BOOKING'),
            ),
          ],
        ),
      );

  void _cancel(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('Booking Cancel करायची?'),
        content: const Text('Cancellation rules पुढील build मध्ये लागू होतील.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('No')),
          FilledButton(
              onPressed: () {
                Navigator.pop(c);
                ScaffoldMessenger.of(c).showSnackBar(
                    const SnackBar(content: Text('Booking cancelled')));
              },
              child: const Text('Cancel')),
        ],
      ),
    );
  }
}

class TripScreen extends StatelessWidget {
  const TripScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Trip in Progress')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.navigation, size: 90),
              const SizedBox(height: 18),
              const Text('Trip सुरू आहे',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Live Location (demo)'),
              const SizedBox(height: 28),
              FilledButton(
                onPressed: () => go(context, const PaymentScreen()),
                child: const Text('END TRIP'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => _sos(context),
                icon: const Icon(Icons.emergency),
                label: const Text('🚨 EMERGENCY HELP'),
              ),
            ]),
          ),
        ),
      );

  void _sos(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('🚨 Emergency'),
        content: const Text(
            'Emergency Call, Share Location किंवा Support यापैकी पर्याय निवडा.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close')),
        ],
      ),
    );
  }
}

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Payment')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Text('Final Fare'),
            const Text('₹900',
                style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: const Icon(Icons.account_balance_wallet),
                title: const Text('UPI / Online Payment'),
                onTap: () {},
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.payments),
                title: const Text('Cash'),
                onTap: () {},
              ),
            ),
            const Spacer(),
            FilledButton(
              onPressed: () => go(context, const RatingScreen()),
              child: const Text('PAY & CONTINUE'),
            ),
          ]),
        ),
      );
}

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});
  @override State<RatingScreen> createState() => _RatingScreenState();
}
class _RatingScreenState extends State<RatingScreen> {
  int rating = 5;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Rate Driver')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Trip कसा होता?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                    5,
                    (i) => IconButton(
                          iconSize: 42,
                          onPressed: () => setState(() => rating = i + 1),
                          icon: Icon(
                              i < rating ? Icons.star : Icons.star_border),
                        ))),
            const SizedBox(height: 15),
            const TextField(
                maxLines: 3,
                decoration: InputDecoration(
                    hintText: 'Feedback लिहा',
                    border: OutlineInputBorder())),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
              child: const Text('SUBMIT'),
            )
          ]),
        ),
      );
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class ScheduleBookingScreen extends StatefulWidget {
  const ScheduleBookingScreen({super.key});
  @override State<ScheduleBookingScreen> createState() =>
      _ScheduleBookingScreenState();
}
class _ScheduleBookingScreenState extends State<ScheduleBookingScreen> {
  DateTime date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay time = const TimeOfDay(hour: 9, minute: 0);
  String vehicle = 'Car';
  String duration = '4 तास';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver Schedule करा')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: const Text('तारीख'),
            subtitle: Text('${date.day}/${date.month}/${date.year}'),
            onTap: () async {
              final d = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 90)),
                  initialDate: date);
              if (d != null) setState(() => date = d);
            },
          ),
          ListTile(
            leading: const Icon(Icons.access_time),
            title: const Text('वेळ'),
            subtitle: Text(time.format(context)),
            onTap: () async {
              final t = await showTimePicker(context: context, initialTime: time);
              if (t != null) setState(() => time = t);
            },
          ),
          DropdownButtonFormField<String>(
            value: vehicle,
            items: ['Car', 'SUV', 'Other']
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
            onChanged: (v) => setState(() => vehicle = v!),
            decoration: const InputDecoration(
                labelText: 'वाहनाचा प्रकार', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: duration,
            items: ['2 तास', '4 तास', '8 तास', 'पूर्ण दिवस']
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
            onChanged: (v) => setState(() => duration = v!),
            decoration: const InputDecoration(
                labelText: 'Duration', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 20),
          Card(
            child: const ListTile(
              title: Text('Estimated Fare'),
              trailing: Text('₹900',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Admin fare settings नुसार'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.event_available),
            label: const Text('Booking Schedule करा'),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Booking Scheduled ✅')));
            },
          )
        ],
      ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class BookingHistoryScreen extends StatelessWidget {
  const BookingHistoryScreen({super.key});

  String _statusText(String status) {
    switch (status) {
      case 'accepted':
        return 'ACCEPTED';
      case 'rejected':
        return 'REJECTED';
      default:
        return 'PENDING';
    }
  }

  String _dateText(dynamic value) {
    if (value is Timestamp) {
      final d = value.toDate();
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    }
    return 'Date not available';
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Booking History')),
      body: uid.isEmpty
          ? const Center(child: Text('Login session सापडली नाही.'))
          : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('vehicle_rent_requests')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Booking History पाहता आली नाही. Firebase permission तपासा.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data?.docs
                        .where((doc) => (doc.data()['customerId'] ?? '') == uid)
                        .toList() ??
                    [];

                docs.sort((a, b) {
                  final at = a.data()['createdAt'];
                  final bt = b.data()['createdAt'];
                  if (at is Timestamp && bt is Timestamp) return bt.compareTo(at);
                  if (at is Timestamp) return -1;
                  if (bt is Timestamp) return 1;
                  return b.id.compareTo(a.id);
                });

                if (docs.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'तुमची booking history अजून उपलब्ध नाही.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 19),
                      ),
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final d = docs[index].data();
                    final status = (d['status'] ?? 'pending').toString();
                    final vehicle = (d['vehicleType'] ?? 'Vehicle').toString();
                    final service = (d['service'] ?? 'Only Vehicle').toString();
                    final pickup = (d['pickupLocation'] ?? 'Pickup not available').toString();
                    final days = (d['days'] ?? 1).toString();
                    final total = d['finalPrice'] ?? d['total'] ?? 0;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        leading: Icon(
                          status == 'accepted'
                              ? Icons.check_circle
                              : status == 'rejected'
                                  ? Icons.cancel
                                  : Icons.hourglass_top,
                          size: 36,
                        ),
                        title: Text(
                          '$vehicle • $service',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            '${_statusText(status)}\n${_dateText(d['startDate'])} • $days दिवस\nPickup: $pickup',
                          ),
                        ),
                        trailing: Text(
                          '₹$total',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        onTap: status == 'accepted'
                            ? () {
                                final booking = <String, dynamic>{
                                  ...d,
                                  'requestId': docs[index].id,
                                };
                                go(context, VehicleRentBookingDetailsScreen(data: booking));
                              }
                            : null,
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Help & Support')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('काय समस्या आहे?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...[
              'Driver संबंधित समस्या',
              'Payment समस्या',
              'Booking समस्या',
              'Cancellation समस्या',
              'Safety समस्या',
              'इतर समस्या'
            ].map((x) => Card(
                  child: ListTile(
                    title: Text(x),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _ticket(context, x),
                  ),
                )),
          ],
        ),
      );

  void _ticket(BuildContext c, String category) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(category),
        content: const TextField(
          maxLines: 4,
          decoration: InputDecoration(
              hintText: 'तुमची समस्या लिहा...',
              border: OutlineInputBorder()),
        ),
        actions: [
          FilledButton(
              onPressed: () {
                Navigator.pop(c);
                ScaffoldMessenger.of(c).showSnackBar(
                    const SnackBar(content: Text('Complaint submitted ✅')));
              },
              child: const Text('Submit'))
        ],
      ),
    );
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V6
class VehicleOwnerDashboard extends StatelessWidget {
  const VehicleOwnerDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vehicle Owner Dashboard')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('vehicle_rent_requests')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return ListView(
              padding: const EdgeInsets.all(20),
              children: const [
                Icon(Icons.cloud_off, size: 70),
                SizedBox(height: 12),
                Text('Firebase connection / permission setup बाकी आहे.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                Text('Customer request save करण्यासाठी Firestore rules आणि login/auth पुढील टप्प्यात जोडू.',
                    textAlign: TextAlign.center),
              ],
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('सध्या नवीन Vehicle Rent Requests नाहीत.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 20)),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final d = doc.data();
              final status = (d['status'] ?? 'pending').toString();
              final vehicle = (d['vehicleType'] ?? 'Vehicle').toString();
              final service = (d['service'] ?? 'Only Vehicle').toString();
              final total = (d['total'] ?? 0).toString();
              final days = (d['days'] ?? 1).toString();
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('$vehicle • $service',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text('₹$total • $days दिवस • Status: ${status.toUpperCase()}'),
                      const SizedBox(height: 4),
                      Text('Pickup: ${(d['pickupLocation'] ?? '—').toString()}'),
                      if (status == 'pending') ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: () => _acceptRequest(context, doc.id, d),
                                icon: const Icon(Icons.check),
                                label: const Text('Accept'),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _updateStatus(doc.id, 'rejected'),
                                icon: const Icon(Icons.close),
                                label: const Text('Reject'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _updateStatus(String id, String status) async {
    await FirebaseFirestore.instance
        .collection('vehicle_rent_requests')
        .doc(id)
        .update({
      'status': status,
      'ownerUpdatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> _acceptRequest(
      BuildContext context, String id, Map<String, dynamic> data) async {
    final nameController = TextEditingController(
      text: (data['ownerName'] ?? 'Vehicle Owner').toString(),
    );
    final phoneController = TextEditingController(
      text: (data['ownerPhone'] ?? '').toString(),
    );
    final priceController = TextEditingController(
      text: (data['total'] ?? 0).toString(),
    );

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Booking Confirm करा'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Vehicle Owner Name',
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                maxLength: 10,
                decoration: const InputDecoration(
                  labelText: 'Owner Mobile Number',
                  prefixIcon: Icon(Icons.phone),
                  counterText: '',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Final Price (₹)',
                  prefixIcon: Icon(Icons.currency_rupee),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final phone = phoneController.text.trim();
              final price = int.tryParse(priceController.text.trim()) ?? 0;
              if (!RegExp(r'^[6-9]\d{9}$').hasMatch(phone)) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(
                    content: Text('कृपया 10 अंकी वैध Mobile Number टाका.'),
                  ),
                );
                return;
              }
              if (price <= 0) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(
                    content: Text('कृपया Final Price योग्य रक्कम टाका.'),
                  ),
                );
                return;
              }
              Navigator.pop(dialogContext, true);
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );

    if (result != true) return;

    final ownerName = nameController.text.trim().isEmpty
        ? 'Vehicle Owner'
        : nameController.text.trim();
    final ownerPhone = phoneController.text.trim();
    final finalPrice = int.tryParse(priceController.text.trim()) ??
        int.tryParse((data['total'] ?? 0).toString()) ??
        0;

    await FirebaseFirestore.instance
        .collection('vehicle_rent_requests')
        .doc(id)
        .update({
      'status': 'accepted',
      'ownerName': ownerName,
      'ownerPhone': ownerPhone,
      'finalPrice': finalPrice,
      'ownerUpdatedAt': FieldValue.serverTimestamp(),
    });
  }
}

class VehicleRentBookingDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> data;

  const VehicleRentBookingDetailsScreen({super.key, required this.data});

  String _dateText(dynamic value) {
    if (value is Timestamp) {
      final d = value.toDate();
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    }
    return value?.toString() ?? '—';
  }

  @override
  Widget build(BuildContext context) {
    final vehicle = (data['vehicleType'] ?? 'Vehicle').toString();
    final service = (data['service'] ?? 'Only Vehicle').toString();
    final pickup = (data['pickupLocation'] ?? 'Current location (demo)').toString();
    final days = (data['days'] ?? 1).toString();
    final estimated = (data['total'] ?? 0).toString();
    final finalPrice = data['finalPrice'];
    final ownerName = (data['ownerName'] ?? 'Vehicle Owner').toString();
    final ownerPhone = (data['ownerPhone'] ?? '').toString();
    final requestId = (data['requestId'] ?? '—').toString();

    return Scaffold(
      appBar: AppBar(title: const Text('Booking Details')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 34,
                    child: Icon(Icons.check, size: 38),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Booking Confirmed ✅',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '$vehicle • $service',
                    style: const TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '📋 Booking Information',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  _detailRow(Icons.directions_car, 'Vehicle', '$vehicle • $service'),
                  _detailRow(Icons.location_on, 'Pickup Location', pickup),
                  _detailRow(Icons.calendar_month, 'Start Date', _dateText(data['startDate'])),
                  _detailRow(Icons.event, 'Rental Duration', '$days दिवस'),
                  _detailRow(Icons.currency_rupee, 'Estimated Price', '₹$estimated'),
                  _detailRow(
                    Icons.price_check,
                    'Final Price',
                    finalPrice == null ? '₹$estimated' : '₹${finalPrice.toString()}',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '👤 Vehicle Owner',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    ownerName,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    ownerPhone.isEmpty
                        ? 'Mobile number उपलब्ध नाही'
                        : '📞 $ownerPhone',
                    style: const TextStyle(fontSize: 17),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => _showCallInfo(context, ownerPhone),
                          icon: const Icon(Icons.call),
                          label: const Text('Call Owner'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _showPickupInfo(context, pickup),
                          icon: const Icon(Icons.map),
                          label: const Text('Pickup'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: const Icon(Icons.confirmation_number),
              title: const Text('Booking ID'),
              subtitle: Text(requestId),
              trailing: IconButton(
                tooltip: 'Copy',
                icon: const Icon(Icons.copy),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: requestId));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Booking ID copied')),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'टीप: Final price आणि pickup details Vehicle Owner/Admin availability नुसार बदलू शकतात.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _detailRow(IconData icon, String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 23),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(fontSize: 17)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showCallInfo(BuildContext context, String phone) async {
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Owner mobile number उपलब्ध नाही.')),
      );
      return;
    }
    final uri = Uri(scheme: 'tel', path: phone);
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        throw Exception('dialer unavailable');
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Call करता आला नाही: $phone')),
        );
      }
    }
  }

  Future<void> _showPickupInfo(BuildContext context, String pickup) async {
    if (pickup.trim().isEmpty || pickup.trim() == '—') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pickup location उपलब्ध नाही.')),
      );
      return;
    }

    final query = Uri.encodeComponent(pickup.trim());
    final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=$query');

    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google Maps/Browser उघडता आले नाही.')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Google Maps/Browser उघडता आले नाही.')),
        );
      }
    }
  }
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});
  @override State<DriverDashboard> createState() => _DriverDashboardState();
}
class _DriverDashboardState extends State<DriverDashboard> {
  bool online = false;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Dashboard')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: SwitchListTile(
                value: online,
                onChanged: (v) => setState(() => online = v),
                title: Text(online ? '🟢 ONLINE' : '🔴 OFFLINE',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(online
                    ? 'Booking requests receive होतील'
                    : 'Online होण्यासाठी Admin approval आवश्यक'),
              ),
            ),
            const Card(
              child: ListTile(
                leading: CircleAvatar(child: Icon(Icons.person)),
                title: Text('Raj Patil'),
                subtitle: Text('⭐ 4.8 • KYC Verified • Car'),
              ),
            ),
            const SizedBox(height: 12),
            const Text('आजची माहिती',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const Card(
              child: ListTile(
                title: Text('आजच्या Bookings'),
                trailing: Text('5'),
              ),
            ),
            const Card(
              child: ListTile(
                title: Text('आजची कमाई'),
                trailing: Text('₹1,850'),
              ),
            ),
            const Card(
              child: ListTile(
                title: Text('My Earnings'),
                trailing: Text('₹32,500'),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => go(context, const DriverRegistrationScreen()),
              icon: const Icon(Icons.person_add),
              label: const Text('Driver Registration'),
            ),
          ],
        ),
      );
}

// TOP_LEVEL_CLASS_BOUNDARY_V4
class DriverRegistrationScreen extends StatelessWidget {
  const DriverRegistrationScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Registration')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Driver म्हणून नोंदणी करा',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            ...[
              'पूर्ण नाव',
              'Mobile Number',
              'Driving Licence',
              'ID Proof',
              'Vehicle Number',
              'RC Document'
            ].map((label) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    decoration: InputDecoration(
                        labelText: label, border: const OutlineInputBorder()),
                  ),
                )),
            FilledButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => const AlertDialog(
                  title: Text('Registration Received ✅'),
                  content: Text(
                      'तुमची माहिती Admin verification साठी पाठवली आहे.'),
                ),
              ),
              child: const Text('Registration Submit करा'),
            ),
          ],
        ),
      );
}
