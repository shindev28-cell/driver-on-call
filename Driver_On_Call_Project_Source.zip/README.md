# Driver On Call

Flutter MVP for an on-demand driver booking app.

- Android package target: `com.driveroncall.app`
- Firebase project configuration is included in `android/app/google-services.json`.
- Firebase Authentication and Firestore integration will be added in the next build phase.
