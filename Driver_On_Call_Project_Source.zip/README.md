# Driver On Call

Flutter MVP for an on-demand driver booking app.

Current build includes:
- Customer home
- Now booking flow
- Scheduled booking
- Demo driver search and assignment
- Trip, payment and rating screens
- Booking history
- Help & Support
- Driver dashboard
- Driver registration

Note: GPS, real-time driver matching, OTP, Firebase/Firestore, payment gateway and production SOS integrations are not yet live.
