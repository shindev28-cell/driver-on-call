
import 'package:flutter/material.dart';

void main() => runApp(const DriverOnCall());

class DriverOnCall extends StatelessWidget {
  const DriverOnCall({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Driver On Call',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5866A3)),
        scaffoldBackgroundColor: const Color(0xFFF9F7FC),
      ),
      home: const HomeScreen(),
    );
  }
}

void go(BuildContext c, Widget page) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => page));

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String vehicle = 'Car';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver On Call',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Driver Mode',
            icon: const Icon(Icons.drive_eta),
            onPressed: () => go(context, const DriverDashboard()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(28, 28, 28, 24),
        children: [
          const Text('नमस्कार! 👋',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('गरज असेल तेव्हा Driver तुमच्या जवळ.',
              style: TextStyle(fontSize: 18)),
          const SizedBox(height: 30),
          _mainButton(context, Icons.flash_on, 'आत्ता Driver हवा', () {
            go(context, const NowBookingScreen());
          }),
          _mainButton(context, Icons.calendar_month, 'Driver Schedule करा', () {
            go(context, const ScheduleBookingScreen());
          }),
          const SizedBox(height: 14),
          Card(
            elevation: 1,
            child: ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              leading: const Icon(Icons.location_on, size: 30),
              title: const Text('Pickup Location',
                  style: TextStyle(fontSize: 19)),
              subtitle: const Text('Current location (demo)',
                  style: TextStyle(fontSize: 16)),
              trailing: IconButton(
                icon: const Icon(Icons.edit_location_alt),
                onPressed: () => _locationDialog(context),
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Text('वाहनाचा प्रकार',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: ['Car', 'SUV', 'Other'].map((v) {
              return ChoiceChip(
                label: Text(v == 'Car' ? '🚗 Car' : v == 'SUV' ? '🚙 SUV' : '🛻 Other'),
                selected: vehicle == v,
                onSelected: (_) => setState(() => vehicle = v),
              );
            }).toList(),
          ),
          const SizedBox(height: 22),
          _menuCard(context, Icons.history, 'Booking History',
              () => go(context, const BookingHistoryScreen())),
          _menuCard(context, Icons.support_agent, 'Help & Support',
              () => go(context, const SupportScreen())),
        ],
      ),
    );
  }

  Widget _mainButton(BuildContext c, IconData icon, String text, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(64),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        onPressed: tap,
        icon: Icon(icon, size: 30),
        label: Text(text, style: const TextStyle(fontSize: 21)),
      ),
    );
  }

  Widget _menuCard(
      BuildContext c, IconData icon, String title, VoidCallback tap) {
    return Card(
      child: ListTile(
        leading: Icon(icon, size: 30),
        title: Text(title, style: const TextStyle(fontSize: 19)),
        trailing: const Icon(Icons.chevron_right),
        onTap: tap,
      ),
    );
  }

  void _locationDialog(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('Pickup Location'),
        content: const Text(
            'Real GPS/Map integration पुढील build मध्ये जोडू. सध्या demo location वापरली आहे.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('OK'))
        ],
      ),
    );
  }
}

class NowBookingScreen extends StatefulWidget {
  const NowBookingScreen({super.key});
  @override State<NowBookingScreen> createState() => _NowBookingScreenState();
}

class _NowBookingScreenState extends State<NowBookingScreen> {
  String duration = '4 तास';
  String purpose = 'माझी गाडी Driver ने चालवावी';
  String vehicle = 'Car';

  @override
  Widget build(BuildContext context) {
    final fare = vehicle == 'SUV' ? 1200 : vehicle == 'Other' ? 1050 : 900;
    return Scaffold(
      appBar: AppBar(title: const Text('आता Driver हवा')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _section('📍 Pickup Location',
              const Text('Current location (demo)')),
          _section('🚗 वाहनाचा प्रकार',
              DropdownButtonFormField<String>(
                value: vehicle,
                items: ['Car', 'SUV', 'Other']
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() => vehicle = v!),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              )),
          _section('Driver कशासाठी हवा?',
              DropdownButtonFormField<String>(
                value: purpose,
                items: [
                  'माझी गाडी Driver ने चालवावी',
                  'Driver सोबत वाहन हवे'
                ]
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: (v) => setState(() => purpose = v!),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              )),
          _section('⏱️ किती वेळासाठी?',
              Wrap(
                spacing: 8,
                children: ['2 तास', '4 तास', '8 तास', 'पूर्ण दिवस']
                    .map((v) => ChoiceChip(
                          label: Text(v),
                          selected: duration == v,
                          onSelected: (_) => setState(() => duration = v),
                        ))
                    .toList(),
              )),
          Card(
            child: ListTile(
              title: const Text('अंदाजे भाडे'),
              trailing: Text('₹$fare',
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold)),
              subtitle: const Text('Admin fare settings नुसार estimate'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.flash_on),
            label: const Text('Driver शोधा',
                style: TextStyle(fontSize: 19)),
            onPressed: () => go(context, SearchingDriverScreen(
              vehicle: vehicle, duration: duration, fare: fare,
            )),
          ),
        ],
      ),
    );
  }

  Widget _section(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            child,
          ],
        ),
      );
}

class SearchingDriverScreen extends StatelessWidget {
  final String vehicle, duration;
  final int fare;
  const SearchingDriverScreen(
      {super.key, required this.vehicle, required this.duration, required this.fare});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver शोधत आहे')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 25),
            const Text('जवळचा Driver शोधत आहे...',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text('$vehicle • $duration • अंदाजे ₹$fare'),
            const SizedBox(height: 30),
            FilledButton(
              onPressed: () => go(context, const AssignedScreen()),
              child: const Text('Demo: Driver मिळाला'),
            ),
          ]),
        ),
      ),
    );
  }
}

class AssignedScreen extends StatelessWidget {
  const AssignedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Confirmed ✅')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const CircleAvatar(radius: 52, child: Icon(Icons.person, size: 56)),
            const SizedBox(height: 12),
            const Center(
                child: Text('Raj Patil',
                    style:
                        TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
            const Center(child: Text('⭐ 4.8  •  ✓ Verified Driver')),
            const SizedBox(height: 18),
            Card(
              child: Column(children: [
                const ListTile(
                    leading: Icon(Icons.directions_car),
                    title: Text('Car'),
                    subtitle: Text('MH-XX-1234')),
                ListTile(
                    leading: const Icon(Icons.location_on),
                    title: const Text('ETA'),
                    subtitle: const Text('8 minutes • Live location (demo)')),
                ListTile(
                    leading: const Icon(Icons.phone),
                    title: const Text('Call Driver'),
                    onTap: () {}),
              ]),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => go(context, const TripScreen()),
              child: const Text('START / VIEW TRIP'),
            ),
            OutlinedButton(
              onPressed: () => _cancel(context),
              child: const Text('CANCEL BOOKING'),
            ),
          ],
        ),
      );

  void _cancel(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('Booking Cancel करायची?'),
        content: const Text('Cancellation rules पुढील build मध्ये लागू होतील.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('No')),
          FilledButton(
              onPressed: () {
                Navigator.pop(c);
                ScaffoldMessenger.of(c).showSnackBar(
                    const SnackBar(content: Text('Booking cancelled')));
              },
              child: const Text('Cancel')),
        ],
      ),
    );
  }
}

class TripScreen extends StatelessWidget {
  const TripScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Trip in Progress')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.navigation, size: 90),
              const SizedBox(height: 18),
              const Text('Trip सुरू आहे',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Live Location (demo)'),
              const SizedBox(height: 28),
              FilledButton(
                onPressed: () => go(context, const PaymentScreen()),
                child: const Text('END TRIP'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => _sos(context),
                icon: const Icon(Icons.emergency),
                label: const Text('🚨 EMERGENCY HELP'),
              ),
            ]),
          ),
        ),
      );

  void _sos(BuildContext c) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: const Text('🚨 Emergency'),
        content: const Text(
            'Emergency Call, Share Location किंवा Support यापैकी पर्याय निवडा.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close')),
        ],
      ),
    );
  }
}

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Payment')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Text('Final Fare'),
            const Text('₹900',
                style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: const Icon(Icons.account_balance_wallet),
                title: const Text('UPI / Online Payment'),
                onTap: () {},
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.payments),
                title: const Text('Cash'),
                onTap: () {},
              ),
            ),
            const Spacer(),
            FilledButton(
              onPressed: () => go(context, const RatingScreen()),
              child: const Text('PAY & CONTINUE'),
            ),
          ]),
        ),
      );
}

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});
  @override State<RatingScreen> createState() => _RatingScreenState();
}
class _RatingScreenState extends State<RatingScreen> {
  int rating = 5;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Rate Driver')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Trip कसा होता?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                    5,
                    (i) => IconButton(
                          iconSize: 42,
                          onPressed: () => setState(() => rating = i + 1),
                          icon: Icon(
                              i < rating ? Icons.star : Icons.star_border),
                        ))),
            const SizedBox(height: 15),
            const TextField(
                maxLines: 3,
                decoration: InputDecoration(
                    hintText: 'Feedback लिहा',
                    border: OutlineInputBorder())),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
              child: const Text('SUBMIT'),
            )
          ]),
        ),
      );

class ScheduleBookingScreen extends StatefulWidget {
  const ScheduleBookingScreen({super.key});
  @override State<ScheduleBookingScreen> createState() =>
      _ScheduleBookingScreenState();
}
class _ScheduleBookingScreenState extends State<ScheduleBookingScreen> {
  DateTime date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay time = const TimeOfDay(hour: 9, minute: 0);
  String vehicle = 'Car';
  String duration = '4 तास';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver Schedule करा')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ListTile(
            leading: const Icon(Icons.calendar_today),
            title: const Text('तारीख'),
            subtitle: Text('${date.day}/${date.month}/${date.year}'),
            onTap: () async {
              final d = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 90)),
                  initialDate: date);
              if (d != null) setState(() => date = d);
            },
          ),
          ListTile(
            leading: const Icon(Icons.access_time),
            title: const Text('वेळ'),
            subtitle: Text(time.format(context)),
            onTap: () async {
              final t = await showTimePicker(context: context, initialTime: time);
              if (t != null) setState(() => time = t);
            },
          ),
          DropdownButtonFormField<String>(
            value: vehicle,
            items: ['Car', 'SUV', 'Other']
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
            onChanged: (v) => setState(() => vehicle = v!),
            decoration: const InputDecoration(
                labelText: 'वाहनाचा प्रकार', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: duration,
            items: ['2 तास', '4 तास', '8 तास', 'पूर्ण दिवस']
                .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                .toList(),
            onChanged: (v) => setState(() => duration = v!),
            decoration: const InputDecoration(
                labelText: 'Duration', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 20),
          Card(
            child: const ListTile(
              title: Text('Estimated Fare'),
              trailing: Text('₹900',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              subtitle: Text('Admin fare settings नुसार'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.event_available),
            label: const Text('Booking Schedule करा'),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Booking Scheduled ✅')));
            },
          )
        ],
      ),
    );
  }
}

class BookingHistoryScreen extends StatelessWidget {
  const BookingHistoryScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Booking History')),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: const [
            Card(
              child: ListTile(
                leading: CircleAvatar(child: Icon(Icons.check)),
                title: Text('Completed • Raj Patil'),
                subtitle: Text('Today • Car • 4 तास'),
                trailing: Text('₹900'),
              ),
            ),
          ],
        ),
      );
}

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Help & Support')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('काय समस्या आहे?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...[
              'Driver संबंधित समस्या',
              'Payment समस्या',
              'Booking समस्या',
              'Cancellation समस्या',
              'Safety समस्या',
              'इतर समस्या'
            ].map((x) => Card(
                  child: ListTile(
                    title: Text(x),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _ticket(context, x),
                  ),
                )),
          ],
        ),
      );

  void _ticket(BuildContext c, String category) {
    showDialog(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(category),
        content: const TextField(
          maxLines: 4,
          decoration: InputDecoration(
              hintText: 'तुमची समस्या लिहा...',
              border: OutlineInputBorder()),
        ),
        actions: [
          FilledButton(
              onPressed: () {
                Navigator.pop(c);
                ScaffoldMessenger.of(c).showSnackBar(
                    const SnackBar(content: Text('Complaint submitted ✅')));
              },
              child: const Text('Submit'))
        ],
      ),
    );
  }
}

class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});
  @override State<DriverDashboard> createState() => _DriverDashboardState();
}
class _DriverDashboardState extends State<DriverDashboard> {
  bool online = false;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Dashboard')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: SwitchListTile(
                value: online,
                onChanged: (v) => setState(() => online = v),
                title: Text(online ? '🟢 ONLINE' : '🔴 OFFLINE',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(online
                    ? 'Booking requests receive होतील'
                    : 'Online होण्यासाठी Admin approval आवश्यक'),
              ),
            ),
            const Card(
              child: ListTile(
                leading: CircleAvatar(child: Icon(Icons.person)),
                title: Text('Raj Patil'),
                subtitle: Text('⭐ 4.8 • KYC Verified • Car'),
              ),
            ),
            const SizedBox(height: 12),
            const Text('आजची माहिती',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const Card(
              child: ListTile(
                title: Text('आजच्या Bookings'),
                trailing: Text('5'),
              ),
            ),
            const Card(
              child: ListTile(
                title: Text('आजची कमाई'),
                trailing: Text('₹1,850'),
              ),
            ),
            const Card(
              child: ListTile(
                title: Text('My Earnings'),
                trailing: Text('₹32,500'),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => go(context, const DriverRegistrationScreen()),
              icon: const Icon(Icons.person_add),
              label: const Text('Driver Registration'),
            ),
          ],
        ),
      );
}

class DriverRegistrationScreen extends StatelessWidget {
  const DriverRegistrationScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver Registration')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Driver म्हणून नोंदणी करा',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            ...[
              'पूर्ण नाव',
              'Mobile Number',
              'Driving Licence',
              'ID Proof',
              'Vehicle Number',
              'RC Document'
            ].map((label) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    decoration: InputDecoration(
                        labelText: label, border: const OutlineInputBorder()),
                  ),
                )),
            FilledButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => const AlertDialog(
                  title: Text('Registration Received ✅'),
                  content: Text(
                      'तुमची माहिती Admin verification साठी पाठवली आहे.'),
                ),
              ),
              child: const Text('Registration Submit करा'),
            ),
          ],
        ),
      );
}
