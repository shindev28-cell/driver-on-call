import 'package:flutter/material.dart';

void main() => runApp(const DriverOnCall());

class DriverOnCall extends StatelessWidget {
  const DriverOnCall({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Driver On Call',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void open(BuildContext c, Widget page) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver On Call',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Driver Mode',
            icon: const Icon(Icons.drive_eta),
            onPressed: () => open(context, const DriverScreen()),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('नमस्कार! 👋',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('गरज असेल तेव्हा Driver तुमच्या जवळ.'),
          const SizedBox(height: 20),
          _bigButton(context, Icons.flash_on, 'आत्ता Driver हवा',
              () => open(context, const DriverListScreen())),
          _bigButton(context, Icons.calendar_month, 'Driver Schedule करा',
              () => open(context, const BookingScreen())),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.location_on),
              title: const Text('Pickup Location'),
              subtitle: const Text('Current location (demo)'),
              trailing: IconButton(
                icon: const Icon(Icons.edit_location_alt),
                onPressed: () {},
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('वाहनाचा प्रकार',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const Wrap(
            spacing: 8,
            children: [
              Chip(label: Text('🚗 Car')),
              Chip(label: Text('🚙 SUV')),
              Chip(label: Text('🛻 Other')),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            child: ListTile(
              leading: const Icon(Icons.history),
              title: const Text('Booking History'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {},
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.support_agent),
              title: const Text('Help & Support'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _bigButton(BuildContext c, IconData icon, String text, VoidCallback tap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: FilledButton.icon(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(62),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: tap,
        icon: Icon(icon, size: 28),
        label: Text(text, style: const TextStyle(fontSize: 18)),
      ),
    );
  }
}

class DriverListScreen extends StatelessWidget {
  const DriverListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final drivers = [
      ['Raj Patil', '4.8', '8 वर्षे', '1.2 km', '₹600'],
      ['Amit Shinde', '4.7', '6 वर्षे', '2.1 km', '₹650'],
      ['Suresh Jadhav', '4.9', '10 वर्षे', '3.0 km', '₹700'],
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Available Drivers')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: drivers.map((d) => Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(12),
            leading: const CircleAvatar(radius: 28, child: Icon(Icons.person)),
            title: Text(d[0],
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('⭐ ${d[1]}  •  ${d[2]}  •  ${d[3]}'),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(d[4], style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                FilledButton(
                  onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const BookingScreen())),
                  child: const Text('BOOK'),
                )
              ],
            ),
          ),
        )).toList(),
      ),
    );
  }
}

class BookingScreen extends StatelessWidget {
  const BookingScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Confirm Booking')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Booking Details',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          const Card(
            child: Column(
              children: [
                ListTile(leading: Icon(Icons.location_on),
                  title: Text('Pickup'), subtitle: Text('Current location')),
                ListTile(leading: Icon(Icons.calendar_today),
                  title: Text('Date'), subtitle: Text('Today')),
                ListTile(leading: Icon(Icons.access_time),
                  title: Text('Time'), subtitle: Text('7:00 PM')),
                ListTile(leading: Icon(Icons.timer),
                  title: Text('Duration'), subtitle: Text('4 Hours')),
                ListTile(leading: Icon(Icons.person),
                  title: Text('Driver'), subtitle: Text('Raj Patil • ⭐ 4.8 • Verified')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Text('Estimated amount: ₹600',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () => Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => const AssignedScreen())),
            child: const Text('CONFIRM BOOKING'),
          ),
        ],
      ),
    );
  }
}

class AssignedScreen extends StatelessWidget {
  const AssignedScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Driver Assigned')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const CircleAvatar(radius: 48, child: Icon(Icons.person, size: 50)),
          const SizedBox(height: 12),
          const Center(child: Text('Raj Patil',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
          const Center(child: Text('⭐ 4.8  •  ✓ Verified Driver')),
          const SizedBox(height: 20),
          Card(child: Column(children: [
            ListTile(leading: const Icon(Icons.phone),
              title: const Text('Call Driver'), onTap: () {}),
            ListTile(leading: const Icon(Icons.chat),
              title: const Text('Chat'), onTap: () {}),
            ListTile(leading: const Icon(Icons.map),
              title: const Text('Live Location'), onTap: () {}),
          ])),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const TripScreen())),
            child: const Text('START / VIEW TRIP'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: () {}, child: const Text('CANCEL BOOKING')),
        ],
      ),
    );
  }
}

class TripScreen extends StatelessWidget {
  const TripScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Trip in Progress')),
    body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.navigation, size: 90),
        const SizedBox(height: 20),
        const Text('Trip in Progress',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Duration: 02:15 hrs'),
        const SizedBox(height: 30),
        FilledButton(
          onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const PaymentScreen())),
          child: const Text('END TRIP'),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.emergency),
          label: const Text('EMERGENCY HELP'),
        ),
      ]),
    )),
  );
}

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Payment')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const Text('Total Amount'),
        const Text('₹600',
            style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Card(child: ListTile(
          leading: const Icon(Icons.account_balance_wallet),
          title: const Text('UPI / Online Payment'),
          onTap: () {},
        )),
        Card(child: ListTile(
          leading: const Icon(Icons.payments),
          title: const Text('Cash'),
          onTap: () {},
        )),
        const Spacer(),
        FilledButton(
          onPressed: () => Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (_) => const RatingScreen())),
          child: const Text('PAY & CONTINUE'),
        )
      ]),
    ),
  );
}

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});
  @override State<RatingScreen> createState() => _RatingScreenState();
}
class _RatingScreenState extends State<RatingScreen> {
  int rating = 5;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Rate Driver')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('Trip कसा होता?',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(5, (i) => IconButton(
            iconSize: 42,
            onPressed: () => setState(() => rating = i + 1),
            icon: Icon(i < rating ? Icons.star : Icons.star_border),
          ))),
        const SizedBox(height: 15),
        const TextField(maxLines: 3,
          decoration: InputDecoration(hintText: 'Feedback लिहा',
            border: OutlineInputBorder())),
        const SizedBox(height: 18),
        FilledButton(
          onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
          child: const Text('SUBMIT'),
        )
      ]),
    ),
  );
}

class DriverScreen extends StatelessWidget {
  const DriverScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Driver Dashboard')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: SwitchListTile(
        value: true, onChanged: (_) {},
        title: const Text('AVAILABLE 🟢',
            style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: const Text('Booking requests receive होतील'),
      )),
      Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: const Text('Raj Patil'),
        subtitle: const Text('⭐ 4.8 • 8 वर्षे • KYC Verified'),
      )),
      const SizedBox(height: 12),
      const Text('New Booking Request',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      Card(child: Column(children: [
        const ListTile(
          title: Text('Customer: Rahul'),
          subtitle: Text('📍 2.5 km • Today 7:00 PM • 4 Hours'),
        ),
        const ListTile(
          leading: Icon(Icons.currency_rupee),
          title: Text('Your Earnings'),
          subtitle: Text('₹500'),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          OutlinedButton(onPressed: () {}, child: const Text('REJECT')),
          FilledButton(onPressed: () {}, child: const Text('ACCEPT')),
        ]),
        const SizedBox(height: 8),
      ])),
    ]),
  );
}
