const admin = require('firebase-admin');
const crypto = require('crypto');

const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '');
const keyId = process.env.RAZORPAY_KEY_ID;
const keySecret = process.env.RAZORPAY_KEY_SECRET;
if (!keyId || !keySecret) throw new Error('Missing Razorpay secrets.');
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

async function razorpay(path, options = {}) {
  const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
  const res = await fetch(`https://api.razorpay.com/v1${path}`, {
    ...options,
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });
  const text = await res.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text }; }
  if (!res.ok) throw new Error(`Razorpay ${res.status}: ${JSON.stringify(body)}`);
  return body;
}

function verifySignature(orderId, paymentId, signature) {
  const expected = crypto
    .createHmac('sha256', keySecret)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  const received = Buffer.from(signature || '');
  const expectedBuffer = Buffer.from(expected);
  if (received.length !== expectedBuffer.length) return false;
  return crypto.timingSafeEqual(expectedBuffer, received);
}

async function main() {
  const snap = await db.collection('payment_requests').get();
  let orders = 0;
  let verified = 0;

  for (const doc of snap.docs) {
    const d = doc.data();
    const ref = doc.ref;
    const status = String(d.status || '');

    if (status === 'created' && !d.orderId) {
      const amount = Number(d.amount || 0);
      if (!amount || amount < 1) continue;
      try {
        const order = await razorpay('/orders', {
          method: 'POST',
          body: JSON.stringify({
            amount: Math.round(amount * 100),
            currency: 'INR',
            receipt: `doc_${doc.id}`,
            notes: { bookingId: String(d.bookingId || '') },
          }),
        });
        await ref.update({
          orderId: order.id,
          status: 'order_created',
          orderCreatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
        orders++;
      } catch (e) {
        console.error(`Order failed ${doc.id}:`, e.message);
      }
      continue;
    }

    // Repair the booking if the payment request was already marked paid
    // but the booking document did not receive paymentStatus.
    if (status === 'paid') {
      const bookingId = String(d.bookingId || '').trim();
      if (bookingId) {
        try {
          await db.collection('vehicle_rent_requests').doc(bookingId).update({
            paymentStatus: 'paid',
            ...(d.paymentId ? { paymentId: String(d.paymentId) } : {}),
            ...(d.orderId ? { paymentOrderId: String(d.orderId) } : {}),
            paidAt: d.verifiedAt || admin.firestore.FieldValue.serverTimestamp(),
          });
          console.log(`Booking payment status repaired: ${bookingId}`);
        } catch (e) {
          console.error(`Repair failed ${doc.id}:`, e.message);
        }
      }
      continue;
    }

    if (status === 'payment_submitted' && d.orderId && d.paymentId && d.signature) {
      try {
        const ok = verifySignature(String(d.orderId), String(d.paymentId), String(d.signature));
        if (!ok) {
          await ref.update({ status: 'failed', verification: 'invalid_signature' });
          continue;
        }
        const payment = await razorpay(`/payments/${encodeURIComponent(String(d.paymentId))}`);
        if (payment.status !== 'captured') {
          await ref.update({ status: 'failed', verification: `payment_status_${payment.status}` });
          continue;
        }

        // Update the booking first. If this fails, the payment request remains
        // payment_submitted so a later worker run can retry safely.
        const bookingId = String(d.bookingId || '').trim();
        if (bookingId) {
          await db.collection('vehicle_rent_requests').doc(bookingId).update({
            paymentStatus: 'paid',
            paymentId: String(d.paymentId),
            paymentOrderId: String(d.orderId),
            paidAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        }

        await ref.update({
          status: 'paid',
          verification: 'verified',
          verifiedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
        verified++;
      } catch (e) {
        console.error(`Verify failed ${doc.id}:`, e.message);
      }
    }
  }

  console.log(`Payment worker completed. Orders: ${orders}, Verified: ${verified}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
