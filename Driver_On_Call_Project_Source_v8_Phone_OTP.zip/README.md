# Driver On Call — Vehicle Rent v6

MVP source for the Driver On Call Android app.

## v6 changes
- Customer Vehicle Rent request now prepares a Firestore document in `vehicle_rent_requests`.
- Request includes vehicle type, service type, start date, days, rate, total and demo pickup location.
- Added Vehicle Owner Dashboard to view pending requests and Accept/Reject them.
- Firebase initialization uses the project's Android Firebase configuration.
- App still opens in demo mode if Firebase is unavailable or Firestore permissions are not configured.

## Next production steps
1. Firebase Phone OTP authentication.
2. Firestore security rules with authenticated customer/owner roles.
3. Vehicle-owner registration/KYC and vehicle availability.
4. Live request notifications.
5. Payment and booking confirmation.
